# frozen_string_literal: true

module CertificateAuth
  module Configuration
    DEFAULT_CERTIFICATE_HOST = 'certificado.assinatura.maiocchi.adv.br'
    DEFAULT_APP_HOST = 'documentos.assinatura.maiocchi.adv.br'

    module_function

    def enabled?
      # Fail closed: the application validates time and enrollment, while the dedicated proxy must validate
      # the certificate chain and revocation status (CRL/OCSP) before this flag is enabled.
      ActiveModel::Type::Boolean.new.cast(ENV.fetch('CERTIFICATE_AUTH_ENABLED', 'false'))
    end

    def certificate_host
      ENV.fetch('CERTIFICATE_AUTH_HOST', DEFAULT_CERTIFICATE_HOST).to_s.downcase
    end

    def app_host
      ENV.fetch('CERTIFICATE_AUTH_APP_HOST', DEFAULT_APP_HOST).to_s.downcase
    end
  end
end
