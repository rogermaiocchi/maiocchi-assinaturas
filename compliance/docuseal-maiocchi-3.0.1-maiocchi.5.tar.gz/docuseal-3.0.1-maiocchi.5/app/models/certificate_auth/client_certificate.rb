# frozen_string_literal: true

require 'cgi'
require 'openssl'

module CertificateAuth
  class ClientCertificate
    MAX_HEADER_BYTES = 32.kilobytes
    SUMMARY_FIELDS = %w[CN O OU].freeze

    attr_reader :certificate

    delegate :not_before, :not_after, to: :certificate

    def self.from_forwarded_header(value)
      encoded = value.to_s
      raise ArgumentError, 'missing certificate' if encoded.blank?
      raise ArgumentError, 'certificate header is too large' if encoded.bytesize > MAX_HEADER_BYTES

      pem = CGI.unescape(encoded).gsub('\\n', "\n")
      new(OpenSSL::X509::Certificate.new(pem))
    rescue OpenSSL::X509::CertificateError
      raise ArgumentError, 'invalid certificate'
    end

    def initialize(certificate)
      @certificate = certificate
    end

    def sha256
      Digest::SHA256.hexdigest(certificate.to_der)
    end

    def issuer_summary
      summarize(certificate.issuer)
    end

    def serial_number
      certificate.serial.to_s(16).upcase.encode(Encoding::UTF_8)
    end

    def subject_summary
      summarize(certificate.subject)
    end

    def temporally_valid?(at: Time.current)
      at.between?(not_before, not_after)
    end

    def attributes_for_challenge
      {
        certificate_sha256: sha256,
        certificate_issuer_summary: issuer_summary,
        certificate_serial_number: serial_number,
        certificate_subject_summary: subject_summary,
        certificate_not_before: not_before,
        certificate_not_after: not_after
      }
    end

    private

    def summarize(name)
      name.to_a.filter_map do |entry, value, _type|
        next unless SUMMARY_FIELDS.include?(entry)

        key = entry.to_s.dup.force_encoding(Encoding::UTF_8).scrub
        normalized = value.to_s.dup.force_encoding(Encoding::UTF_8).scrub
        "#{key}=#{normalized.gsub(/[\r\n]/, ' ').strip}"
      end.join(', ').encode(Encoding::UTF_8).first(500).presence || 'Não informado'
    end
  end
end
