# Maiocchi. Assinatura — aviso de personalização

Este repositório contém uma distribuição personalizada do DocuSeal 3.0.1 para o portal de assinaturas do **Maiocchi Advogado**.

## Identidade aplicada

- produto visível: **Maiocchi. Assinatura**;
- contato administrativo: **roger@maiocchi.adv.br**;
- paleta institucional: `#0a0a0a`, `#f6f5f1` e `#ffc400`;
- marca visual e ícones próprios do escritório nas interfaces web, PWA e e-mails.

## Software de origem e licença

O motor de documentos e assinaturas permanece DocuSeal. A atribuição discreta “Tecnologia de código aberto DocuSeal” e a oferta de fonte correspondente exigida pela AGPL são preservadas uma única vez em cada interface interativa aplicável.

- o código correspondente desta versão é mantido pelo titular do portal nos termos da AGPL-3.0-only;
- projeto de origem: <https://github.com/docusealco/docuseal/tree/3.0.1>;
- licença do projeto de origem: <https://github.com/docusealco/docuseal/blob/3.0.1/LICENSE>;
- termos adicionais do projeto de origem: <https://github.com/docusealco/docuseal/blob/3.0.1/LICENSE_ADDITIONAL_TERMS>.

A personalização não altera o motor criptográfico nem os metadados técnicos de PDF que identificam o software de origem. Por segurança e privacidade, documentos e trilhas de auditoria são entregues por link seguro, sem anexos de e-mail. Os avisos de copyright e licença existentes no código-fonte permanecem vigentes.

## Operação

Solicitações relacionadas ao portal devem ser encaminhadas exclusivamente a **roger@maiocchi.adv.br**. A publicação deve manter acessível a fonte correspondente exata da versão implantada no endereço indicado acima, sem divulgar o vínculo em e-mails ou superfícies editoriais que não estejam sujeitas à oferta da AGPL.
