# frozen_string_literal: true

class AddSignaturePolicyToSubmitters < ActiveRecord::Migration[8.1]
  def change
    change_table :submitters, bulk: true do |table|
      table.string :signature_mode, limit: 32
      table.string :signature_mode_requirement, limit: 32
      table.string :signature_mode_source, limit: 40
      table.string :signature_policy_version, limit: 40
      table.string :qualified_signature_state, limit: 20
      table.string :qualified_signature_public_id, limit: 40
      table.string :qualified_signature_source_sha256, limit: 64
      table.string :qualified_signature_signed_sha256, limit: 64
      table.jsonb :qualified_signature_receipt, null: false, default: {}
      table.datetime :qualified_signature_completed_at
    end

    add_check_constraint :submitters,
                         <<~SQL.squish,
                           signature_mode IS NULL OR
                           signature_mode IN ('simple', 'advanced', 'qualified_icp_brasil')
                         SQL
                         name: 'submitters_signature_mode_valid'
    add_check_constraint :submitters,
                         <<~SQL.squish,
                           signature_mode_requirement IS NULL OR
                           signature_mode_requirement IN ('simple', 'advanced', 'qualified_icp_brasil')
                         SQL
                         name: 'submitters_signature_mode_requirement_valid'
    add_check_constraint :submitters,
                         <<~SQL.squish,
                           qualified_signature_state IS NULL OR
                           qualified_signature_state IN ('ticketed', 'validated', 'committed', 'failed')
                         SQL
                         name: 'submitters_qualified_signature_state_valid'
    add_check_constraint :submitters,
                         <<~SQL.squish,
                           qualified_signature_source_sha256 IS NULL OR
                           qualified_signature_source_sha256 ~ '^[a-f0-9]{64}$'
                         SQL
                         name: 'submitters_qualified_source_sha256_valid'
    add_check_constraint :submitters,
                         <<~SQL.squish,
                           qualified_signature_signed_sha256 IS NULL OR
                           qualified_signature_signed_sha256 ~ '^[a-f0-9]{64}$'
                         SQL
                         name: 'submitters_qualified_signed_sha256_valid'
    add_check_constraint :submitters,
                         <<~SQL.squish,
                           completed_at IS NULL OR
                           signature_mode IS DISTINCT FROM 'qualified_icp_brasil' OR
                           qualified_signature_state = 'committed'
                         SQL
                         name: 'submitters_qualified_completion_committed'
    add_check_constraint :submitters,
                         <<~SQL.squish,
                           qualified_signature_state IS DISTINCT FROM 'committed' OR (
                             qualified_signature_public_id IS NOT NULL AND
                             qualified_signature_source_sha256 IS NOT NULL AND
                             qualified_signature_signed_sha256 IS NOT NULL AND
                             qualified_signature_completed_at IS NOT NULL
                           )
                         SQL
                         name: 'submitters_qualified_commit_complete'
    add_index :submitters, %i[submission_id signature_mode]
    add_index :submitters, :qualified_signature_public_id, unique: true,
                                                           where: 'qualified_signature_public_id IS NOT NULL'
  end
end
