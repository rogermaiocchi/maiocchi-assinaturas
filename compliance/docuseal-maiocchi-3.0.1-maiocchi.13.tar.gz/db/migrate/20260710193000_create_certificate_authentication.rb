# frozen_string_literal: true

class CreateCertificateAuthentication < ActiveRecord::Migration[8.1]
  def change
    create_table :certificate_identities do |t|
      t.references :user, null: false, foreign_key: true, index: true
      t.string :sha256, null: false, limit: 64
      t.string :issuer_summary, null: false, limit: 500
      t.string :serial_number, null: false, limit: 256
      t.string :subject_summary, null: false, limit: 500
      t.datetime :not_before, null: false
      t.datetime :not_after, null: false
      t.string :status, null: false, default: 'active', limit: 32
      t.datetime :last_used_at

      t.timestamps
    end

    add_index :certificate_identities, :sha256, unique: true
    add_index :certificate_identities, %i[user_id status]

    create_table :certificate_auth_challenges do |t|
      t.references :user, null: true, foreign_key: true, index: true
      t.string :purpose, null: false, limit: 32
      t.string :state_digest, null: false, limit: 64
      t.string :callback_digest, limit: 64
      t.string :certificate_sha256, limit: 64
      t.string :certificate_issuer_summary, limit: 500
      t.string :certificate_serial_number, limit: 256
      t.string :certificate_subject_summary, limit: 500
      t.datetime :certificate_not_before
      t.datetime :certificate_not_after
      t.datetime :expires_at, null: false
      t.datetime :verified_at
      t.datetime :consumed_at

      t.timestamps
    end

    add_index :certificate_auth_challenges, :state_digest, unique: true
    add_index :certificate_auth_challenges, :callback_digest, unique: true
    add_index :certificate_auth_challenges, :expires_at
  end
end
