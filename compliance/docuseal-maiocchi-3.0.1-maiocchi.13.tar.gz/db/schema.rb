# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_07_15_103000) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "btree_gin"
  enable_extension "pg_catalog.plpgsql"

  create_table "access_tokens", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.text "sha256", null: false
    t.text "token", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id", null: false
    t.index ["sha256"], name: "index_access_tokens_on_sha256", unique: true
    t.index ["user_id"], name: "index_access_tokens_on_user_id"
  end

  create_table "account_accesses", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id", null: false
    t.index ["account_id", "user_id"], name: "index_account_accesses_on_account_id_and_user_id", unique: true
  end

  create_table "account_configs", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "created_at", null: false
    t.string "key", null: false
    t.datetime "updated_at", null: false
    t.text "value", null: false
    t.index ["account_id", "key"], name: "index_account_configs_on_account_id_and_key", unique: true
    t.index ["account_id"], name: "index_account_configs_on_account_id"
  end

  create_table "account_linked_accounts", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.text "account_type", null: false
    t.datetime "created_at", null: false
    t.bigint "linked_account_id", null: false
    t.datetime "updated_at", null: false
    t.index ["account_id", "linked_account_id"], name: "idx_on_account_id_linked_account_id_48ab9f79d2", unique: true
    t.index ["account_id"], name: "index_account_linked_accounts_on_account_id"
    t.index ["linked_account_id"], name: "index_account_linked_accounts_on_linked_account_id"
  end

  create_table "accounts", force: :cascade do |t|
    t.datetime "archived_at"
    t.datetime "created_at", null: false
    t.string "locale", null: false
    t.string "name", null: false
    t.string "timezone", null: false
    t.datetime "updated_at", null: false
    t.string "uuid", null: false
    t.index ["uuid"], name: "index_accounts_on_uuid", unique: true
  end

  create_table "active_storage_attachments", force: :cascade do |t|
    t.bigint "blob_id", null: false
    t.datetime "created_at", null: false
    t.string "name", null: false
    t.bigint "record_id", null: false
    t.string "record_type", null: false
    t.string "uuid", null: false
    t.index ["blob_id"], name: "index_active_storage_attachments_on_blob_id"
    t.index ["record_type", "record_id", "name", "blob_id"], name: "idx_on_record_type_record_id_name_blob_id_0be5805727"
    t.index ["uuid"], name: "index_active_storage_attachments_on_uuid"
  end

  create_table "active_storage_blobs", force: :cascade do |t|
    t.bigint "byte_size", null: false
    t.string "checksum"
    t.string "content_type"
    t.datetime "created_at", null: false
    t.string "filename", null: false
    t.string "key", null: false
    t.text "metadata"
    t.string "service_name", null: false
    t.string "uuid"
    t.index ["checksum"], name: "index_active_storage_blobs_on_checksum"
    t.index ["key"], name: "index_active_storage_blobs_on_key", unique: true
    t.index ["uuid"], name: "index_active_storage_blobs_on_uuid", unique: true
  end

  create_table "active_storage_variant_records", force: :cascade do |t|
    t.bigint "blob_id", null: false
    t.string "variation_digest", null: false
    t.index ["blob_id", "variation_digest"], name: "index_active_storage_variant_records_uniqueness", unique: true
  end

  create_table "certificate_auth_challenges", force: :cascade do |t|
    t.string "callback_digest", limit: 64
    t.string "certificate_issuer_summary", limit: 500
    t.datetime "certificate_not_after"
    t.datetime "certificate_not_before"
    t.string "certificate_serial_number", limit: 256
    t.string "certificate_sha256", limit: 64
    t.string "certificate_subject_summary", limit: 500
    t.datetime "consumed_at"
    t.datetime "created_at", null: false
    t.datetime "expires_at", null: false
    t.string "purpose", limit: 32, null: false
    t.string "state_digest", limit: 64, null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id"
    t.datetime "verified_at"
    t.index ["callback_digest"], name: "index_certificate_auth_challenges_on_callback_digest", unique: true
    t.index ["expires_at"], name: "index_certificate_auth_challenges_on_expires_at"
    t.index ["state_digest"], name: "index_certificate_auth_challenges_on_state_digest", unique: true
    t.index ["user_id"], name: "index_certificate_auth_challenges_on_user_id"
  end

  create_table "certificate_identities", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "issuer_summary", limit: 500, null: false
    t.datetime "last_used_at"
    t.datetime "not_after", null: false
    t.datetime "not_before", null: false
    t.string "serial_number", limit: 256, null: false
    t.string "sha256", limit: 64, null: false
    t.string "status", limit: 32, default: "active", null: false
    t.string "subject_summary", limit: 500, null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id", null: false
    t.index ["sha256"], name: "index_certificate_identities_on_sha256", unique: true
    t.index ["user_id", "status"], name: "index_certificate_identities_on_user_id_and_status"
    t.index ["user_id"], name: "index_certificate_identities_on_user_id"
  end

  create_table "completed_documents", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "sha256", null: false
    t.bigint "submitter_id", null: false
    t.datetime "updated_at", null: false
    t.index ["sha256"], name: "index_completed_documents_on_sha256"
    t.index ["submitter_id"], name: "index_completed_documents_on_submitter_id"
  end

  create_table "completed_submitters", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "completed_at", null: false
    t.datetime "created_at", null: false
    t.boolean "is_first"
    t.integer "sms_count", null: false
    t.string "source", null: false
    t.bigint "submission_id", null: false
    t.bigint "submitter_id", null: false
    t.bigint "template_id"
    t.datetime "updated_at", null: false
    t.string "verification_method"
    t.index ["account_id", "completed_at"], name: "index_completed_submitters_account_id_completed_at_is_first", where: "(is_first = true)"
    t.index ["account_id", "completed_at"], name: "index_completed_submitters_on_account_id_and_completed_at"
    t.index ["submission_id"], name: "index_completed_submitters_on_submission_id", unique: true, where: "(is_first = true)"
    t.index ["submitter_id"], name: "index_completed_submitters_on_submitter_id", unique: true
  end

  create_table "console1984_commands", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.bigint "sensitive_access_id"
    t.bigint "session_id", null: false
    t.text "statements"
    t.datetime "updated_at", null: false
    t.index ["sensitive_access_id"], name: "index_console1984_commands_on_sensitive_access_id"
    t.index ["session_id", "created_at", "sensitive_access_id"], name: "on_session_and_sensitive_chronologically"
  end

  create_table "console1984_sensitive_accesses", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.text "justification"
    t.bigint "session_id", null: false
    t.datetime "updated_at", null: false
    t.index ["session_id"], name: "index_console1984_sensitive_accesses_on_session_id"
  end

  create_table "console1984_sessions", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.text "reason"
    t.datetime "updated_at", null: false
    t.bigint "user_id", null: false
    t.index ["created_at"], name: "index_console1984_sessions_on_created_at"
    t.index ["user_id", "created_at"], name: "index_console1984_sessions_on_user_id_and_created_at"
  end

  create_table "console1984_users", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "username", null: false
    t.index ["username"], name: "index_console1984_users_on_username"
  end

  create_table "document_generation_events", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "event_name", null: false
    t.bigint "submitter_id", null: false
    t.datetime "updated_at", null: false
    t.index ["submitter_id", "event_name"], name: "index_document_generation_events_on_submitter_id_and_event_name", unique: true, where: "((event_name)::text = ANY (ARRAY[('start'::character varying)::text, ('complete'::character varying)::text]))"
    t.index ["submitter_id"], name: "index_document_generation_events_on_submitter_id"
  end

  create_table "document_metadata", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.string "blob_checksum", null: false
    t.datetime "created_at", null: false
    t.text "text_runs", null: false
    t.index ["account_id", "blob_checksum"], name: "index_document_metadata_on_account_id_and_blob_checksum", unique: true
  end

  create_table "dynamic_document_versions", force: :cascade do |t|
    t.text "areas", null: false
    t.datetime "created_at", null: false
    t.bigint "dynamic_document_id", null: false
    t.string "sha1", null: false
    t.datetime "updated_at", null: false
    t.index ["dynamic_document_id", "sha1"], name: "idx_on_dynamic_document_id_sha1_3503adf557", unique: true
  end

  create_table "dynamic_documents", force: :cascade do |t|
    t.text "body", null: false
    t.datetime "created_at", null: false
    t.text "head"
    t.string "sha1", null: false
    t.bigint "template_id", null: false
    t.datetime "updated_at", null: false
    t.string "uuid", null: false
    t.index ["template_id"], name: "index_dynamic_documents_on_template_id"
  end

  create_table "email_events", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "created_at", null: false
    t.text "data", null: false
    t.string "email", null: false
    t.bigint "emailable_id", null: false
    t.string "emailable_type", null: false
    t.datetime "event_datetime", null: false
    t.string "event_type", null: false
    t.string "message_id", null: false
    t.string "tag", null: false
    t.index ["account_id", "event_datetime"], name: "index_email_events_on_account_id_and_event_datetime"
    t.index ["email"], name: "index_email_events_on_email"
    t.index ["email"], name: "index_email_events_on_email_event_types", where: "((event_type)::text = ANY (ARRAY[('bounce'::character varying)::text, ('soft_bounce'::character varying)::text, ('permanent_bounce'::character varying)::text, ('complaint'::character varying)::text, ('soft_complaint'::character varying)::text]))"
    t.index ["emailable_type", "emailable_id"], name: "index_email_events_on_emailable"
    t.index ["message_id"], name: "index_email_events_on_message_id"
  end

  create_table "email_messages", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.bigint "author_id", null: false
    t.text "body", null: false
    t.datetime "created_at", null: false
    t.string "sha1", null: false
    t.text "subject", null: false
    t.datetime "updated_at", null: false
    t.string "uuid", null: false
    t.index ["account_id"], name: "index_email_messages_on_account_id"
    t.index ["sha1"], name: "index_email_messages_on_sha1"
    t.index ["uuid"], name: "index_email_messages_on_uuid"
  end

  create_table "encrypted_configs", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "created_at", null: false
    t.string "key", null: false
    t.datetime "updated_at", null: false
    t.text "value", null: false
    t.index ["account_id", "key"], name: "index_encrypted_configs_on_account_id_and_key", unique: true
    t.index ["account_id"], name: "index_encrypted_configs_on_account_id"
  end

  create_table "encrypted_user_configs", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "key", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id", null: false
    t.text "value", null: false
    t.index ["user_id", "key"], name: "index_encrypted_user_configs_on_user_id_and_key", unique: true
    t.index ["user_id"], name: "index_encrypted_user_configs_on_user_id"
  end

  create_table "lock_events", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "event_name", null: false
    t.string "key", null: false
    t.datetime "updated_at", null: false
    t.index ["event_name", "key"], name: "index_lock_events_on_event_name_and_key", unique: true, where: "((event_name)::text = ANY (ARRAY[('start'::character varying)::text, ('complete'::character varying)::text]))"
    t.index ["key"], name: "index_lock_events_on_key"
  end

  create_table "mcp_tokens", force: :cascade do |t|
    t.datetime "archived_at"
    t.datetime "created_at", null: false
    t.string "name", null: false
    t.string "sha256", null: false
    t.string "token_prefix", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id", null: false
    t.index ["sha256"], name: "index_mcp_tokens_on_sha256", unique: true
    t.index ["user_id"], name: "index_mcp_tokens_on_user_id"
  end

  create_table "oauth_access_grants", force: :cascade do |t|
    t.bigint "application_id", null: false
    t.string "code_challenge"
    t.string "code_challenge_method"
    t.datetime "created_at", null: false
    t.integer "expires_in", null: false
    t.text "redirect_uri", null: false
    t.bigint "resource_owner_id", null: false
    t.datetime "revoked_at"
    t.string "scopes", default: "", null: false
    t.string "token", null: false
    t.index ["application_id"], name: "index_oauth_access_grants_on_application_id"
    t.index ["resource_owner_id"], name: "index_oauth_access_grants_on_resource_owner_id"
    t.index ["token"], name: "index_oauth_access_grants_on_token", unique: true
  end

  create_table "oauth_access_tokens", force: :cascade do |t|
    t.bigint "application_id", null: false
    t.datetime "created_at", null: false
    t.integer "expires_in"
    t.string "previous_refresh_token", default: "", null: false
    t.string "refresh_token"
    t.bigint "resource_owner_id"
    t.datetime "revoked_at"
    t.string "scopes"
    t.string "token", null: false
    t.index ["application_id"], name: "index_oauth_access_tokens_on_application_id"
    t.index ["refresh_token"], name: "index_oauth_access_tokens_on_refresh_token", unique: true
    t.index ["resource_owner_id"], name: "index_oauth_access_tokens_on_resource_owner_id"
    t.index ["token"], name: "index_oauth_access_tokens_on_token", unique: true
  end

  create_table "oauth_applications", force: :cascade do |t|
    t.boolean "confidential", default: true, null: false
    t.datetime "created_at", null: false
    t.string "name", null: false
    t.text "redirect_uri"
    t.string "scopes", default: "", null: false
    t.string "secret", null: false
    t.string "uid", null: false
    t.datetime "updated_at", null: false
    t.index ["uid"], name: "index_oauth_applications_on_uid", unique: true
  end

  create_table "search_entries", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "created_at", null: false
    t.tsvector "ngram"
    t.bigint "record_id", null: false
    t.string "record_type", null: false
    t.tsvector "tsvector", null: false
    t.datetime "updated_at", null: false
    t.index ["account_id", "ngram"], name: "index_search_entries_on_account_id_ngram_submission", where: "((record_type)::text = 'Submission'::text)", using: :gin
    t.index ["account_id", "ngram"], name: "index_search_entries_on_account_id_ngram_submitter", where: "((record_type)::text = 'Submitter'::text)", using: :gin
    t.index ["account_id", "ngram"], name: "index_search_entries_on_account_id_ngram_template", where: "((record_type)::text = 'Template'::text)", using: :gin
    t.index ["account_id", "tsvector"], name: "index_search_entries_on_account_id_tsvector_submission", where: "((record_type)::text = 'Submission'::text)", using: :gin
    t.index ["account_id", "tsvector"], name: "index_search_entries_on_account_id_tsvector_submitter", where: "((record_type)::text = 'Submitter'::text)", using: :gin
    t.index ["account_id", "tsvector"], name: "index_search_entries_on_account_id_tsvector_template", where: "((record_type)::text = 'Template'::text)", using: :gin
    t.index ["record_id", "record_type"], name: "index_search_entries_on_record_id_and_record_type", unique: true
  end

  create_table "submission_events", force: :cascade do |t|
    t.bigint "account_id"
    t.datetime "created_at", null: false
    t.text "data", null: false
    t.datetime "event_timestamp", null: false
    t.string "event_type", null: false
    t.bigint "submission_id", null: false
    t.bigint "submitter_id"
    t.datetime "updated_at", null: false
    t.index ["account_id", "created_at"], name: "index_submissions_events_on_sms_event_types", where: "((event_type)::text = ANY (ARRAY[('send_sms'::character varying)::text, ('send_2fa_sms'::character varying)::text]))"
    t.index ["account_id"], name: "index_submission_events_on_account_id"
    t.index ["created_at"], name: "index_submission_events_on_created_at"
    t.index ["submission_id"], name: "index_submission_events_on_submission_id"
    t.index ["submitter_id"], name: "index_submission_events_on_submitter_id"
  end

  create_table "submissions", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "archived_at"
    t.datetime "created_at", null: false
    t.bigint "created_by_user_id"
    t.datetime "expire_at"
    t.text "name"
    t.text "preferences", null: false
    t.string "slug", null: false
    t.string "source", null: false
    t.string "submitters_order", null: false
    t.text "template_fields"
    t.bigint "template_id"
    t.text "template_schema"
    t.text "template_submitters"
    t.datetime "updated_at", null: false
    t.text "variables"
    t.text "variables_schema"
    t.index ["account_id", "id"], name: "index_submissions_on_account_id_and_id"
    t.index ["account_id", "template_id", "id"], name: "index_submissions_on_account_id_and_template_id_and_id", where: "(archived_at IS NULL)"
    t.index ["account_id", "template_id", "id"], name: "index_submissions_on_account_id_and_template_id_and_id_archived", where: "(archived_at IS NOT NULL)"
    t.index ["created_by_user_id"], name: "index_submissions_on_created_by_user_id"
    t.index ["slug"], name: "index_submissions_on_slug", unique: true
    t.index ["template_id"], name: "index_submissions_on_template_id"
  end

  create_table "submitter_versions", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "email"
    t.string "name"
    t.string "phone"
    t.string "slug", null: false
    t.bigint "submitter_id", null: false
    t.datetime "updated_at", null: false
    t.index ["slug"], name: "index_submitter_versions_on_slug"
    t.index ["submitter_id"], name: "index_submitter_versions_on_submitter_id"
  end

  create_table "submitters", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "completed_at"
    t.datetime "created_at", null: false
    t.datetime "declined_at"
    t.string "email"
    t.string "external_id"
    t.string "ip"
    t.text "metadata", null: false
    t.string "name"
    t.datetime "opened_at"
    t.string "phone"
    t.text "preferences", null: false
    t.datetime "qualified_signature_completed_at"
    t.string "qualified_signature_public_id", limit: 40
    t.jsonb "qualified_signature_receipt", default: {}, null: false
    t.string "qualified_signature_signed_sha256", limit: 64
    t.string "qualified_signature_source_sha256", limit: 64
    t.string "qualified_signature_state", limit: 20
    t.datetime "sent_at"
    t.string "signature_mode", limit: 32
    t.string "signature_mode_requirement", limit: 32
    t.string "signature_mode_source", limit: 40
    t.string "signature_policy_version", limit: 40
    t.string "slug", null: false
    t.bigint "submission_id", null: false
    t.string "timezone"
    t.string "ua"
    t.datetime "updated_at", null: false
    t.string "uuid", null: false
    t.text "values", null: false
    t.index ["account_id", "id"], name: "index_submitters_on_account_id_and_id"
    t.index ["completed_at", "account_id"], name: "index_submitters_on_completed_at_and_account_id"
    t.index ["email"], name: "index_submitters_on_email"
    t.index ["external_id"], name: "index_submitters_on_external_id"
    t.index ["qualified_signature_public_id"], name: "index_submitters_on_qualified_signature_public_id", unique: true, where: "(qualified_signature_public_id IS NOT NULL)"
    t.index ["slug"], name: "index_submitters_on_slug", unique: true
    t.index ["submission_id", "signature_mode"], name: "index_submitters_on_submission_id_and_signature_mode"
    t.index ["submission_id"], name: "index_submitters_on_submission_id"
    t.check_constraint "completed_at IS NULL OR signature_mode::text IS DISTINCT FROM 'qualified_icp_brasil'::text OR qualified_signature_state::text = 'committed'::text", name: "submitters_qualified_completion_committed"
    t.check_constraint "qualified_signature_signed_sha256 IS NULL OR qualified_signature_signed_sha256::text ~ '^[a-f0-9]{64}$'::text", name: "submitters_qualified_signed_sha256_valid"
    t.check_constraint "qualified_signature_source_sha256 IS NULL OR qualified_signature_source_sha256::text ~ '^[a-f0-9]{64}$'::text", name: "submitters_qualified_source_sha256_valid"
    t.check_constraint "qualified_signature_state IS NULL OR (qualified_signature_state::text = ANY (ARRAY['ticketed'::character varying::text, 'validated'::character varying::text, 'committed'::character varying::text, 'failed'::character varying::text]))", name: "submitters_qualified_signature_state_valid"
    t.check_constraint "qualified_signature_state::text IS DISTINCT FROM 'committed'::text OR qualified_signature_public_id IS NOT NULL AND qualified_signature_source_sha256 IS NOT NULL AND qualified_signature_signed_sha256 IS NOT NULL AND qualified_signature_completed_at IS NOT NULL", name: "submitters_qualified_commit_complete"
    t.check_constraint "signature_mode IS NULL OR (signature_mode::text = ANY (ARRAY['simple'::character varying::text, 'advanced'::character varying::text, 'qualified_icp_brasil'::character varying::text]))", name: "submitters_signature_mode_valid"
    t.check_constraint "signature_mode_requirement IS NULL OR (signature_mode_requirement::text = ANY (ARRAY['simple'::character varying::text, 'advanced'::character varying::text, 'qualified_icp_brasil'::character varying::text]))", name: "submitters_signature_mode_requirement_valid"
  end

  create_table "template_accesses", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.bigint "template_id", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id", null: false
    t.index ["template_id", "user_id"], name: "index_template_accesses_on_template_id_and_user_id", unique: true
  end

  create_table "template_folders", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "archived_at"
    t.bigint "author_id", null: false
    t.datetime "created_at", null: false
    t.string "name", null: false
    t.bigint "parent_folder_id"
    t.datetime "updated_at", null: false
    t.index ["account_id"], name: "index_template_folders_on_account_id"
    t.index ["author_id"], name: "index_template_folders_on_author_id"
    t.index ["parent_folder_id"], name: "index_template_folders_on_parent_folder_id"
  end

  create_table "template_sharings", force: :cascade do |t|
    t.string "ability", null: false
    t.bigint "account_id", null: false
    t.datetime "created_at", null: false
    t.bigint "template_id", null: false
    t.datetime "updated_at", null: false
    t.index ["account_id", "template_id"], name: "index_template_sharings_on_account_id_and_template_id", unique: true
    t.index ["template_id"], name: "index_template_sharings_on_template_id"
  end

  create_table "template_versions", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.bigint "author_id", null: false
    t.datetime "created_at", null: false
    t.text "data", null: false
    t.string "sha1", null: false
    t.bigint "template_id", null: false
    t.datetime "updated_at", null: false
    t.index ["account_id"], name: "index_template_versions_on_account_id"
    t.index ["author_id"], name: "index_template_versions_on_author_id"
    t.index ["template_id", "sha1"], name: "index_template_versions_on_template_id_and_sha1", unique: true
  end

  create_table "templates", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "archived_at"
    t.bigint "author_id", null: false
    t.datetime "created_at", null: false
    t.string "external_id"
    t.text "fields", null: false
    t.bigint "folder_id", null: false
    t.string "name", null: false
    t.text "preferences", null: false
    t.text "schema", null: false
    t.boolean "shared_link", default: false, null: false
    t.string "slug", null: false
    t.text "source", null: false
    t.text "submitters", null: false
    t.datetime "updated_at", null: false
    t.text "variables_schema"
    t.index ["account_id", "folder_id", "id"], name: "index_templates_on_account_id_and_folder_id_and_id", where: "(archived_at IS NULL)"
    t.index ["account_id", "id"], name: "index_templates_on_account_id_and_id_archived", where: "(archived_at IS NOT NULL)"
    t.index ["account_id"], name: "index_templates_on_account_id"
    t.index ["author_id"], name: "index_templates_on_author_id"
    t.index ["external_id"], name: "index_templates_on_external_id"
    t.index ["folder_id"], name: "index_templates_on_folder_id"
    t.index ["slug"], name: "index_templates_on_slug", unique: true
  end

  create_table "user_configs", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "key", null: false
    t.datetime "updated_at", null: false
    t.bigint "user_id", null: false
    t.text "value", null: false
    t.index ["user_id", "key"], name: "index_user_configs_on_user_id_and_key", unique: true
    t.index ["user_id"], name: "index_user_configs_on_user_id"
  end

  create_table "users", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "archived_at"
    t.datetime "confirmation_sent_at"
    t.string "confirmation_token"
    t.datetime "confirmed_at"
    t.integer "consumed_timestep"
    t.datetime "created_at", null: false
    t.datetime "current_sign_in_at"
    t.string "current_sign_in_ip"
    t.string "email", null: false
    t.string "encrypted_password", null: false
    t.integer "failed_attempts", default: 0, null: false
    t.string "first_name"
    t.string "last_name"
    t.datetime "last_sign_in_at"
    t.string "last_sign_in_ip"
    t.datetime "locked_at"
    t.boolean "otp_required_for_login", default: false, null: false
    t.string "otp_secret"
    t.datetime "remember_created_at"
    t.datetime "reset_password_sent_at"
    t.string "reset_password_token"
    t.string "role", null: false
    t.integer "sign_in_count", default: 0, null: false
    t.string "unconfirmed_email"
    t.string "unlock_token"
    t.datetime "updated_at", null: false
    t.string "uuid", null: false
    t.index ["account_id"], name: "index_users_on_account_id"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
    t.index ["unlock_token"], name: "index_users_on_unlock_token", unique: true
    t.index ["uuid"], name: "index_users_on_uuid", unique: true
  end

  create_table "webhook_attempts", force: :cascade do |t|
    t.integer "attempt", null: false
    t.datetime "created_at", null: false
    t.text "response_body"
    t.integer "response_status_code", null: false
    t.datetime "updated_at", null: false
    t.bigint "webhook_event_id", null: false
    t.index ["webhook_event_id"], name: "index_webhook_attempts_on_webhook_event_id"
  end

  create_table "webhook_events", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "created_at", null: false
    t.string "event_type", null: false
    t.bigint "record_id", null: false
    t.string "record_type", null: false
    t.string "status", null: false
    t.datetime "updated_at", null: false
    t.string "uuid", null: false
    t.bigint "webhook_url_id", null: false
    t.index ["uuid", "webhook_url_id"], name: "index_webhook_events_on_uuid_and_webhook_url_id", unique: true
    t.index ["webhook_url_id", "id"], name: "index_webhook_events_error", where: "((status)::text = 'error'::text)"
    t.index ["webhook_url_id", "id"], name: "index_webhook_events_on_webhook_url_id_and_id"
  end

  create_table "webhook_urls", force: :cascade do |t|
    t.bigint "account_id", null: false
    t.datetime "created_at", null: false
    t.text "events", null: false
    t.text "hmac_secret", null: false
    t.text "secret", null: false
    t.string "sha1", null: false
    t.datetime "updated_at", null: false
    t.text "url", null: false
    t.index ["account_id"], name: "index_webhook_urls_on_account_id"
    t.index ["sha1"], name: "index_webhook_urls_on_sha1"
  end

  add_foreign_key "access_tokens", "users"
  add_foreign_key "account_accesses", "accounts"
  add_foreign_key "account_configs", "accounts"
  add_foreign_key "account_linked_accounts", "accounts"
  add_foreign_key "account_linked_accounts", "accounts", column: "linked_account_id"
  add_foreign_key "active_storage_attachments", "active_storage_blobs", column: "blob_id"
  add_foreign_key "active_storage_variant_records", "active_storage_blobs", column: "blob_id"
  add_foreign_key "certificate_auth_challenges", "users"
  add_foreign_key "certificate_identities", "users"
  add_foreign_key "document_generation_events", "submitters"
  add_foreign_key "document_metadata", "accounts"
  add_foreign_key "dynamic_document_versions", "dynamic_documents"
  add_foreign_key "dynamic_documents", "templates"
  add_foreign_key "email_events", "accounts"
  add_foreign_key "email_messages", "accounts"
  add_foreign_key "email_messages", "users", column: "author_id"
  add_foreign_key "encrypted_configs", "accounts"
  add_foreign_key "encrypted_user_configs", "users"
  add_foreign_key "mcp_tokens", "users"
  add_foreign_key "oauth_access_grants", "oauth_applications", column: "application_id"
  add_foreign_key "oauth_access_grants", "users", column: "resource_owner_id"
  add_foreign_key "oauth_access_tokens", "oauth_applications", column: "application_id"
  add_foreign_key "oauth_access_tokens", "users", column: "resource_owner_id"
  add_foreign_key "submission_events", "accounts"
  add_foreign_key "submission_events", "submissions"
  add_foreign_key "submission_events", "submitters"
  add_foreign_key "submissions", "templates"
  add_foreign_key "submissions", "users", column: "created_by_user_id"
  add_foreign_key "submitter_versions", "submitters"
  add_foreign_key "submitters", "submissions"
  add_foreign_key "template_accesses", "templates"
  add_foreign_key "template_folders", "accounts"
  add_foreign_key "template_folders", "template_folders", column: "parent_folder_id"
  add_foreign_key "template_folders", "users", column: "author_id"
  add_foreign_key "template_sharings", "templates"
  add_foreign_key "template_versions", "accounts"
  add_foreign_key "template_versions", "templates"
  add_foreign_key "template_versions", "users", column: "author_id"
  add_foreign_key "templates", "accounts"
  add_foreign_key "templates", "template_folders", column: "folder_id"
  add_foreign_key "templates", "users", column: "author_id"
  add_foreign_key "user_configs", "users"
  add_foreign_key "users", "accounts"
  add_foreign_key "webhook_urls", "accounts"
end
