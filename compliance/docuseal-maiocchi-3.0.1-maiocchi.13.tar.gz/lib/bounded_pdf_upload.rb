# frozen_string_literal: true

module BoundedPdfUpload
  class TooLarge < StandardError; end

  module_function

  def read!(upload, max_bytes:)
    declared_size = upload.size if upload.respond_to?(:size)
    raise TooLarge, 'O PDF excede o limite de 40 MB.' if declared_size.present? && declared_size.to_i > max_bytes

    upload.rewind if upload.respond_to?(:rewind)
    bytes = upload.read(max_bytes + 1)
    raise TooLarge, 'O PDF excede o limite de 40 MB.' if bytes.bytesize > max_bytes

    bytes
  end
end
