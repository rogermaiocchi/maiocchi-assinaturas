# frozen_string_literal: true

module ImageUtils
  ACCEPTED_CONTENT_TYPES = %w[
    image/png
    image/jpeg
    image/webp
    image/gif
    image/x-icon
    image/vnd.microsoft.icon
    image/bmp
    image/x-bmp
    image/x-ms-bmp
  ].freeze
  ICO_REGEXP = %r{\Aimage/(?:x-icon|vnd\.microsoft\.icon)\z}
  BMP_REGEXP = %r{\Aimage/(?:bmp|x-bmp|x-ms-bmp)\z}

  module_function

  def load_vips(data, content_type: nil, autorot: false)
    raise ArgumentError, 'content_type must be a string' if content_type && !content_type.is_a?(String)

    detected_content_type = Marcel::MimeType.for(StringIO.new(data))

    unless ACCEPTED_CONTENT_TYPES.include?(detected_content_type)
      raise Vips::Error, "Formato de imagem não permitido: #{detected_content_type}"
    end

    if ICO_REGEXP.match?(detected_content_type)
      LoadIco.call(data)
    elsif BMP_REGEXP.match?(detected_content_type)
      LoadBmp.call(data)
    else
      image = Vips::Image.new_from_buffer(data, '')

      autorot ? image.autorot : image
    end
  end

  def blank?(image)
    stats = image.stats

    min = (0...image.bands).map { |i| stats.getpoint(0, i)[0] }
    max = (0...image.bands).map { |i| stats.getpoint(1, i)[0] }

    return true if min.all?(255) && max.all?(255)
    return true if min.all?(0) && max.all?(0)

    false
  end

  def error?(image)
    image = image.crop(0, 0, image.width / 4, 2)

    row1, row2 = image.to_a

    row1[3..] == row2[..-4] && row1.each_cons(2).none? { |a, b| a == b }
  end
end
