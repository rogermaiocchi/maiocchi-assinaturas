# frozen_string_literal: true

module MaiocchiSignaturePolicy
  SIMPLE = 'simple'
  ADVANCED = 'advanced'
  QUALIFIED = 'qualified_icp_brasil'
  DEFAULT_MODE = SIMPLE
  STANDARD_MODES = [SIMPLE, ADVANCED].freeze
  SIGNER_MODES = [SIMPLE, ADVANCED, QUALIFIED].freeze
  MODE_RANK = SIGNER_MODES.each_with_index.to_h.freeze
  POLICY_VERSION = '2026-07-15-v1'

  InvalidMode = Class.new(ArgumentError)

  MODES = {
    SIMPLE => {
      label: 'SIMPLES RASTREÁVEL',
      format: 'Assinatura eletrônica',
      infrastructure: 'Maiocchi. Assinatura',
      legal_basis: 'MP 2.200-2/2001, art. 10, § 2º · Lei 14.063/2020, art. 4º, I'
    },
    ADVANCED => {
      label: 'AVANÇADA',
      format: 'Assinatura eletrônica avançada',
      infrastructure: 'Maiocchi. Assinatura · OTP por e-mail',
      legal_basis: 'Lei 14.063/2020, art. 4º, II'
    },
    QUALIFIED => {
      label: 'ICP-BRASIL',
      format: 'PAdES',
      infrastructure: 'ICP-Brasil',
      legal_basis: 'MP 2.200-2/2001, art. 10, § 1º · Lei 14.063/2020, art. 4º, III'
    }
  }.freeze

  TRACEABILITY_CONFIGS = [
    AccountConfig::FLATTEN_RESULT_PDF_KEY,
    AccountConfig::WITH_SIGNATURE_ID,
    AccountConfig::WITH_TIMESTAMP_SECONDS_KEY,
    AccountConfig::WITH_SUBMITTER_TIMEZONE_KEY,
    AccountConfig::WITH_AUDIT_VALUES_KEY,
    AccountConfig::WITH_AUDIT_SENDER_KEY,
    AccountConfig::COMBINE_PDF_RESULT_KEY
  ].freeze

  PUBLIC_ID_PATTERN = /
    \AMAI-(\d{4})
    -([0-9A-HJKMNP-TV-Z]{4})-([0-9A-HJKMNP-TV-Z]{4})
    -([0-9A-HJKMNP-TV-Z]{4})-([0-9A-HJKMNP-TV-Z]{4})\z
  /x
  BASE32_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'

  module_function

  def normalize(mode)
    MODES.key?(mode.to_s) ? mode.to_s : DEFAULT_MODE
  end

  def normalize_standard(mode)
    STANDARD_MODES.include?(mode.to_s) ? mode.to_s : DEFAULT_MODE
  end

  def validate_mode!(mode, allowed: SIGNER_MODES)
    normalized = mode.presence || DEFAULT_MODE
    return normalized if allowed.include?(normalized)

    raise InvalidMode, 'A modalidade de assinatura informada não é válida.'
  end

  def mode_for(record)
    signer_mode = record.signature_mode if record.respond_to?(:signature_mode)
    return normalize(signer_mode) if signer_mode.present?

    direct_mode = record&.preferences&.dig('signature_mode')
    return normalize(direct_mode) if direct_mode.present?

    submission = record.submission if record.respond_to?(:submission)
    submission_mode = submission&.preferences&.dig('signature_mode')
    return normalize(submission_mode) if submission_mode.present?

    template = record.template if record.respond_to?(:template)
    template_mode = template&.preferences&.dig('signature_mode')
    normalize(template_mode)
  end

  def required_mode_for(submitter)
    persisted = submitter.signature_mode_requirement if submitter.respond_to?(:signature_mode_requirement)
    return normalize(persisted) if persisted.present?

    direct = submitter.preferences&.dig('signature_mode_requirement') ||
             submitter.preferences&.dig('signature_mode')
    return normalize(direct) if direct.present?

    submission_mode = submitter.submission&.preferences&.dig('signature_mode')
    return normalize(submission_mode) if submission_mode.present?

    template = submitter.submission&.template
    normalize(template&.preferences&.dig('signature_mode'))
  end

  def allowed_modes_for(submitter)
    minimum = MODE_RANK.fetch(required_mode_for(submitter))
    SIGNER_MODES.select { |mode| MODE_RANK.fetch(mode) >= minimum }
  end

  def config_for(record)
    MODES.fetch(mode_for(record))
  end

  def completed_signer_modes(submission)
    submission.submitters.filter_map do |submitter|
      mode_for(submitter) if submitter.completed_at?
    end.uniq
  end

  def aggregate_mode_for(submission)
    modes = completed_signer_modes(submission)
    return mode_for(submission) if modes.empty?
    return modes.first if modes.one?

    'mixed'
  end

  def aggregate_config_for(submission)
    modes = completed_signer_modes(submission)
    return config_for(submission) if modes.empty?
    return MODES.fetch(modes.first) if modes.one?

    configs = modes.map { |mode| MODES.fetch(mode) }
    {
      label: 'MISTA',
      format: configs.map { |config| config.fetch(:format) }.uniq.join(' + '),
      infrastructure: configs.map { |config| config.fetch(:infrastructure) }.uniq.join(' + '),
      legal_basis: configs.map { |config| config.fetch(:legal_basis) }.uniq.join(' · ')
    }
  end

  def label(record)
    config_for(record).fetch(:label)
  end

  def legal_basis(record)
    config_for(record).fetch(:legal_basis)
  end

  def apply_to_template!(template, mode)
    normalized = validate_mode!(mode, allowed: STANDARD_MODES)
    template.preferences ||= {}
    template.preferences['signature_mode'] = normalized
    template.preferences['require_email_2fa'] = normalized == ADVANCED
    template
  end

  def apply_to_submitter!(submitter, mode, source: 'signer_choice', save: true)
    normalized = validate_mode!(mode)
    requirement = required_mode_for(submitter)
    unless allowed_modes_for(submitter).include?(normalized)
      raise InvalidMode,
            "A modalidade exigida para este documento é #{MODES.fetch(requirement).fetch(:label)} ou superior."
    end

    submitter.preferences ||= {}
    submitter.signature_mode_requirement = requirement
    submitter.signature_mode = normalized
    submitter.signature_policy_version = POLICY_VERSION
    submitter.signature_mode_source = source
    if normalized == ADVANCED || requirement == ADVANCED
      submitter.preferences['require_email_2fa'] = true
    else
      submitter.preferences.delete('require_email_2fa')
    end
    clear_uncommitted_qualified_attempt!(submitter) if normalized != QUALIFIED
    submitter.save! if save
    submitter
  end

  def clear_uncommitted_qualified_attempt!(submitter)
    return if submitter.qualified_signature_state == 'committed'

    submitter.qualified_signature_state = nil
    submitter.qualified_signature_public_id = nil
    submitter.qualified_signature_source_sha256 = nil
    submitter.qualified_signature_signed_sha256 = nil
    submitter.qualified_signature_receipt = {}
    submitter.qualified_signature_completed_at = nil
    submitter.preferences.delete('qualified_signature_attempt')
  end

  def snapshot_submitter!(submitter, source: 'submission_snapshot', save: true)
    submitter.signature_mode_requirement ||= required_mode_for(submitter)
    if submitter.signature_mode.present?
      submitter.save! if save && submitter.changed?
      return submitter
    end

    apply_to_submitter!(submitter, required_mode_for(submitter), source: source, save: save)
  end

  def apply_to_submission!(submission)
    submission.preferences ||= {}
    submission.preferences['signature_mode'] = mode_for(submission)
    submission.preferences['evidence_id'] = public_id(submission)
    submission.preferences['document_number'] = document_number(submission)
    submission.save! if submission.changed?
    submission
  end

  def ensure_account_traceability!(account)
    TRACEABILITY_CONFIGS.each do |key|
      config = account.account_configs.find_or_initialize_by(key: key)
      next if config.persisted? && config.value == true

      config.value = true
      config.save!
    end
  end

  def public_id(submission)
    return submission.preferences['evidence_id'] if submission.preferences&.dig('evidence_id').present?
    raise ArgumentError, 'submission must be persisted' unless submission.persisted?

    year = submission.created_at.year
    encoded_id = encode_integer(submission.id, 8)
    signature = evidence_signature(year, encoded_id, submission.slug)
    "MAI-#{year}-#{(encoded_id + signature).scan(/.{4}/).join('-')}"
  end

  def find_completed_by_public_id(code)
    match = code.to_s.upcase.match(PUBLIC_ID_PATTERN)
    return unless match

    encoded_id = match.captures[1, 2].join
    submission = Submission.find_by(id: decode_integer(encoded_id))
    return unless submission
    return unless ActiveSupport::SecurityUtils.secure_compare(public_id(submission), code.to_s.upcase)
    return if submission.submitters.exists?(completed_at: nil)

    submission
  end

  def verify_url(submission)
    "#{MaiocchiBrand::HOME_URL}/validar?codigo=#{public_id(submission)}"
  end

  def document_number(submission)
    existing = submission.preferences&.dig('document_number').to_s
    return existing if existing.match?(/\A\d{29}\z/)
    raise ArgumentError, 'submission must be persisted' unless submission.persisted?

    stamp = submission.created_at.utc.strftime('%Y%m%d%H%M%S')
    digest = OpenSSL::HMAC.digest('SHA256', evidence_secret, "document-number:#{submission.id}:#{submission.slug}")
    entropy = digest.first(8).unpack1('Q>').modulo(10**15).to_s.rjust(15, '0')
    "#{stamp}#{entropy}"
  end

  def encode_integer(value, length)
    number = Integer(value)
    encoded = +''
    length.times do
      encoded.prepend(BASE32_ALPHABET[number % 32])
      number /= 32
    end
    raise ArgumentError, 'value is too large' unless number.zero?

    encoded
  end

  def decode_integer(value)
    value.each_char.reduce(0) { |number, char| (number * 32) + BASE32_ALPHABET.index(char).to_i }
  end

  def evidence_signature(year, encoded_id, slug)
    digest = OpenSSL::HMAC.digest('SHA256', evidence_secret, "#{year}:#{encoded_id}:#{slug}")
    number = digest.bytes.first(5).reduce(0) { |memo, byte| (memo << 8) | byte }
    encode_integer(number, 8)
  end

  def evidence_secret
    ENV['MAIOCCHI_EVIDENCE_HMAC_KEY'].presence ||
      ENV['AUTHENTICITY_INTERNAL_HMAC_KEY'].presence ||
      Rails.application.secret_key_base
  end
end
