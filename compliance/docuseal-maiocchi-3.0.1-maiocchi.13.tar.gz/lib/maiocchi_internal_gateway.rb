# frozen_string_literal: true

require 'openssl'
require 'digest'
require 'securerandom'

module MaiocchiInternalGateway
  MAX_CLOCK_SKEW = 5.minutes
  RESPONSE_HEADER = 'X-Maiocchi-Response-Signature'

  Error = Class.new(StandardError)

  module_function

  def request_auth(payload, method:, uri:)
    timestamp = Time.now.to_i.to_s
    nonce = SecureRandom.hex(16)
    verb = method.to_s.upcase
    target = uri.request_uri
    raise Error, 'O método da requisição interna é inválido.' unless verb.match?(/\A[A-Z]+\z/)
    unless target.start_with?('/') && !target.match?(/[\r\n]/)
      raise Error,
            'O destino da requisição interna é inválido.'
    end

    request_digest = Digest::SHA256.hexdigest(payload)
    message = [timestamp, nonce, verb, target, request_digest].join("\n")
    digest = OpenSSL::HMAC.hexdigest('SHA256', hmac_key, message)
    {
      header: "#{timestamp}.#{nonce}.#{digest}",
      timestamp: timestamp,
      nonce: nonce,
      request_digest: request_digest,
      method: verb,
      target: target
    }
  end

  def verify_response!(response, request_auth:)
    timestamp, nonce, request_digest, received = response[RESPONSE_HEADER].to_s.split('.', 4)
    unless timestamp&.match?(/\A\d{10}\z/) && nonce&.match?(/\A[a-f0-9]{32}\z/) &&
           request_digest&.match?(/\A[a-f0-9]{64}\z/) && received&.match?(/\A[a-f0-9]{64}\z/)
      raise Error, 'A resposta do gateway interno não possui autenticação válida.'
    end

    raise Error, 'A resposta do gateway interno expirou.' if (Time.now.to_i - timestamp.to_i).abs > MAX_CLOCK_SKEW
    unless nonce == request_auth.fetch(:nonce) && request_digest == request_auth.fetch(:request_digest)
      raise Error, 'A resposta do gateway interno não corresponde à requisição enviada.'
    end

    response_digest = Digest::SHA256.hexdigest(response.body.to_s)
    message = [timestamp, nonce, request_digest, response.code.to_s, response_digest].join("\n")
    expected = OpenSSL::HMAC.hexdigest('SHA256', hmac_key, message)
    return true if ActiveSupport::SecurityUtils.secure_compare(expected, received)

    raise Error, 'A resposta do gateway interno não passou na verificação de integridade.'
  end

  def hmac_key
    direct = ENV['AUTHENTICITY_INTERNAL_HMAC_KEY'].presence
    file = ENV['AUTHENTICITY_INTERNAL_HMAC_KEY_FILE'].presence
    raise Error, 'A autenticação interna possui configuração ambígua.' if direct && file

    key = file ? File.binread(file).strip : direct
    raise Error, 'A autenticação interna não está configurada.' if key.blank? || key.bytesize < 32

    key
  rescue Errno::EACCES, Errno::ENOENT => e
    raise Error, "O segredo de autenticação interna não pôde ser lido (#{e.class.name})."
  end
end
