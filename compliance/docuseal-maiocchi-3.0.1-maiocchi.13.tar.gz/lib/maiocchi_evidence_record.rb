# frozen_string_literal: true

module MaiocchiEvidenceRecord
  module_function

  def call(submission)
    attachment = submission.combined_document_attachment
    raise PrivateEvidenceComposer::Error, 'O PDF final não está disponível.' unless attachment

    bytes = attachment.download
    audit = submission.audit_trail_attachment
    public_id = MaiocchiSignaturePolicy.public_id(submission)
    preferences = submission.preferences || {}
    embedded_attestation = preferences['pqc_attestation']
    pqc = preferences['final_pqc_attestation']
    manifest = preferences['final_evidence_manifest']
    unless preferences['final_pqc_code'].present? && preferences['final_pqc_code'] == pqc&.dig('code')
      raise PrivateEvidenceComposer::Error, 'O código do atestado final não confere.'
    end

    proof_verified = PrivateEvidenceComposer.verify_final_pdf!(
      pdf: bytes,
      manifest:,
      attestation: pqc,
      embedded_attestation:
    )
    proof = proof_for(pqc, verified: proof_verified)

    {
      documentStatus: 'active',
      proofVerified: proof_verified,
      envelope: {
        record: build_record(submission:, attachment:, bytes:, audit:, public_id:, pqc:, proof:, manifest:),
        proof: proof
      }
    }
  end

  def build_record(submission:, attachment:, bytes:, audit:, public_id:, pqc:, proof:, manifest:)
    sha256 = Digest::SHA256.hexdigest(bytes)
    config = MaiocchiSignaturePolicy.aggregate_config_for(submission)

    {
      schema: 'br.adv.maiocchi.evidence',
      version: '1.0',
      document: document_record(submission, attachment, bytes, public_id, sha256, manifest),
      signature: signature_record(submission, config),
      validation: validation_record(audit, pqc, proof, sha256),
      representation: representation_record(bytes, sha256),
      goldStandard: gold_standard_record(submission, config, public_id),
      disclosure: { mode: 'restricted' },
      links: links_record(submission, proof)
    }
  end

  def document_record(submission, attachment, bytes, public_id, sha256, manifest)
    {
      id: public_id,
      revision: 1,
      mediaType: 'application/pdf',
      size: bytes.bytesize,
      name: attachment.filename.to_s,
      number: MaiocchiSignaturePolicy.document_number(submission),
      pageCount: pdf_page_count(bytes),
      hash: { algorithm: 'SHA-256', value: sha256 },
      finalizedAt: manifest.fetch('finalizedAt')
    }
  end

  def signature_record(submission, config)
    {
      format: config.fetch(:format),
      infrastructure: config.fetch(:infrastructure),
      profile: config.fetch(:label),
      policyOid: nil,
      count: submission.submitters.count(&:completed_at?),
      docMdp: 'not_applicable'
    }
  end

  def validation_record(audit, pqc, proof, sha256)
    audit_bytes = audit&.download
    report_hash = audit_bytes ? Digest::SHA256.hexdigest(audit_bytes) : sha256
    attestation_hash = pqc&.dig('manifestSha256').presence || sha256

    {
      status: proof.present? ? 'valid' : 'invalid',
      validatedAt: Time.current.iso8601,
      validator: 'Maiocchi. Assinatura · trilha de auditoria',
      attestation: (proof || { type: 'unverified', algorithm: nil }).merge(
        hash: { algorithm: 'SHA-256', value: attestation_hash }
      ),
      report: {
        mediaType: 'application/pdf',
        size: audit&.byte_size.to_i,
        hash: { algorithm: 'SHA-256', value: report_hash }
      }
    }
  end

  def representation_record(bytes, sha256)
    {
      type: 'embedded-evidence-page',
      mediaType: 'application/pdf',
      size: bytes.bytesize,
      hash: { algorithm: 'SHA-256', value: sha256 }
    }
  end

  def gold_standard_record(submission, config, public_id)
    modality = MaiocchiSignaturePolicy.aggregate_mode_for(submission)

    {
      barcodeValue: "MAI|#{public_id}|R1",
      intendedFor: 'Destinatários identificados no documento',
      purpose: evidence_purpose(modality),
      signingLocation: signer_locations(submission),
      tokenType: config.fetch(:infrastructure),
      signatureType: "#{config.fetch(:format)} · #{config.fetch(:label)}",
      signers: signers(submission)
    }
  end

  def evidence_purpose(modality)
    case modality
    when MaiocchiSignaturePolicy::ADVANCED
      'Assinatura eletrônica avançada'
    when MaiocchiSignaturePolicy::QUALIFIED
      'Assinatura digital qualificada ICP-Brasil'
    when 'mixed'
      'Assinaturas em modalidades distintas, individualizadas por signatário'
    else
      'Assinatura eletrônica documentada'
    end
  end

  def links_record(submission, proof)
    key_id = proof&.dig(:keyId)

    {
      verify: MaiocchiSignaturePolicy.verify_url(submission),
      original: nil,
      print: nil,
      officialValidator: nil,
      postQuantumKey: key_id.present? ? "#{MaiocchiBrand::HOME_URL}/chaves-pqc/#{key_id}.pem" : nil
    }
  end

  def proof_for(pqc, verified:)
    return unless verified && pqc.is_a?(Hash)

    {
      type: 'ML-DSA', algorithm: 'ML-DSA-65', keyId: pqc['keyId'], code: pqc['code'],
      scope: 'final-pdf-record', value: pqc['signatureBase64url']
    }
  end

  def signers(submission)
    roles = submission.template_submitters.to_a.index_by { |item| item['uuid'] }
    submission.submitters.select(&:completed_at).map do |submitter|
      mode = MaiocchiSignaturePolicy.mode_for(submitter)
      config = MaiocchiSignaturePolicy::MODES.fetch(mode)
      {
        name: submitter.name.presence || 'Signatário identificado no documento',
        role: roles.dig(submitter.uuid, 'name') || 'Signatário',
        modality: mode,
        profile: config.fetch(:label),
        format: config.fetch(:format),
        infrastructure: config.fetch(:infrastructure),
        legalBasis: config.fetch(:legal_basis),
        certificateFingerprintSha256: '',
        signedAt: submitter.completed_at.iso8601
      }
    end
  end

  def signer_locations(submission)
    zones = submission.submitters.filter_map(&:timezone).uniq
    zones.presence&.join(', ') || submission.account.timezone
  end

  def pdf_page_count(bytes)
    HexaPDF::Document.new(io: StringIO.new(bytes)).pages.count
  rescue HexaPDF::Error
    nil
  end
end
