# frozen_string_literal: true

class SettingsMailer < ApplicationMailer
  def smtp_successful_setup(email)
    mail(to: email, subject: 'Configuração de e-mail concluída')
  end
end
