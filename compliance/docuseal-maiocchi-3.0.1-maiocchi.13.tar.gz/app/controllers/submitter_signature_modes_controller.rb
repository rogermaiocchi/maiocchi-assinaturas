# frozen_string_literal: true

class SubmitterSignatureModesController < ApplicationController
  layout 'form'

  skip_before_action :authenticate_user!
  skip_authorization_check

  before_action :load_submitter
  before_action :ensure_active_submitter
  before_action :ensure_verified_access, only: :update
  before_action :snapshot_signature_mode

  def show
    @current_mode = MaiocchiSignaturePolicy.mode_for(@submitter)
    @required_mode = MaiocchiSignaturePolicy.required_mode_for(@submitter)
    @remote_available = PrivatePadesTickets.remote_available?
  end

  def update
    mode = MaiocchiSignaturePolicy.validate_mode!(params[:signature_mode])
    MaiocchiSignaturePolicy.apply_to_submitter!(@submitter, mode)
    SubmissionEvents.create_with_tracking_data(
      @submitter,
      'select_signature_mode',
      request,
      { signature_mode: mode, policy_version: MaiocchiSignaturePolicy::POLICY_VERSION }
    )

    if mode == MaiocchiSignaturePolicy::QUALIFIED
      redirect_to new_qualified_signature_path(submitter_slug: @submitter.slug)
    else
      redirect_to submit_form_path(@submitter.slug)
    end
  rescue MaiocchiSignaturePolicy::InvalidMode => e
    redirect_to submit_form_signature_mode_path(@submitter.slug), alert: e.message
  end

  private

  def load_submitter
    @submitter = Submitter.find_by!(slug: params[:submit_form_slug])
  end

  def ensure_active_submitter
    invalid = @submitter.completed_at? || @submitter.declined_at? || @submitter.submission.expired? ||
              @submitter.submission.archived_at? || @submitter.submission.template&.archived_at?
    raise ActionController::RoutingError, I18n.t('not_found') if invalid
  end

  def snapshot_signature_mode
    MaiocchiSignaturePolicy.snapshot_submitter!(@submitter)
  end

  def ensure_verified_access
    return if Submitters::AuthorizedForForm.call(@submitter, current_user, request)

    redirect_to submit_form_path(@submitter.slug),
                alert: I18n.t('verification_required_refresh_the_page_and_pass_2fa')
  end
end
