# frozen_string_literal: true

class QualifiedSignatureCompletionsController < ApplicationController
  skip_before_action :authenticate_user!
  skip_authorization_check
  skip_forgery_protection

  def create
    RateLimit.call("qualified-signature-completion-#{request.remote_ip}", limit: 10, ttl: 10.minutes, enabled: true)
    ticket = params.require(:ticket).to_s
    unless ticket.match?(/\A[A-Za-z0-9_-]{43}\z/)
      raise QualifiedSignatures::Commit::Error,
            'O ticket qualificado é inválido.'
    end

    submitter = QualifiedSignatures::Commit.call(ticket:, request:)
    render json: {
      status: 'committed',
      publicId: submitter.qualified_signature_public_id,
      redirectUrl: submit_form_completed_path(submitter.slug)
    }
  rescue QualifiedSignatures::Commit::Error, PrivatePadesTickets::Error, ActionController::ParameterMissing => e
    render json: { error: { code: 'qualified_commit_rejected', message: e.message } }, status: :unprocessable_content
  end
end
