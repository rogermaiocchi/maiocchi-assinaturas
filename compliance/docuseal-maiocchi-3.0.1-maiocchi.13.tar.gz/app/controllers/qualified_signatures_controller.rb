# frozen_string_literal: true

class QualifiedSignaturesController < ApplicationController
  layout 'form'

  skip_before_action :authenticate_user!
  skip_authorization_check

  before_action :load_submitter
  before_action :authorize_access
  before_action :ensure_verified_submitter

  def new
    @remote_available = PrivatePadesTickets.remote_available?
  end

  def create
    rate_limit!
    pdf, document_name = qualified_source

    result = PrivatePadesTickets.create(
      pdf:,
      document_name:,
      intended_for: params[:intended_for],
      purpose: params[:purpose],
      submitter: @submitter
    )

    register_attempt!(result) if @submitter

    redirect_to PrivatePadesTickets.local_ticket_path(result.fetch('url'))
  rescue PrivatePadesTickets::Error, BoundedPdfUpload::TooLarge => e
    flash.now[:alert] = e.message
    @remote_available = PrivatePadesTickets.remote_available?
    render :new, status: :unprocessable_content
  end

  private

  def load_submitter
    @submitter = Submitter.find_by!(slug: params[:submitter_slug]) if params[:submitter_slug].present?
  end

  def authorize_access
    if @submitter
      invalid = @submitter.completed_at? || @submitter.declined_at? || @submitter.submission.expired? ||
                @submitter.submission.archived_at? || @submitter.submission.template&.archived_at?
      raise ActionController::RoutingError, I18n.t('not_found') if invalid

      return
    end

    authenticate_user!
    authorize!(:create, Template)
  end

  def rate_limit!
    actor = @submitter ? "submitter-#{@submitter.id}" : "user-#{current_user.id}"
    RateLimit.call("qualified-signature-#{actor}", limit: 5, ttl: 10.minutes, enabled: true)
  rescue RateLimit::LimitApproached
    raise PrivatePadesTickets::Error, 'Limite temporário atingido. Aguarde antes de preparar outro documento.'
  end

  def ensure_verified_submitter
    return unless @submitter
    return if Submitters::AuthorizedForForm.call(@submitter, current_user, request)

    redirect_to submit_form_path(@submitter.slug),
                alert: I18n.t('verification_required_refresh_the_page_and_pass_2fa')
  end

  def qualified_source
    return QualifiedSignatures::CanonicalSource.call(@submitter, request) if @submitter

    upload = params[:pdf]
    raise PrivatePadesTickets::Error, 'Selecione o PDF que será assinado.' unless upload.respond_to?(:read)

    [BoundedPdfUpload.read!(upload, max_bytes: PrivatePadesTickets::MAX_PDF_BYTES), upload.original_filename]
  end

  def register_attempt!(result)
    MaiocchiSignaturePolicy.apply_to_submitter!(@submitter, MaiocchiSignaturePolicy::QUALIFIED, save: false)
    @submitter.preferences['qualified_signature_attempt'] = {
      'public_id' => result.fetch('publicId'),
      'document_number' => result.fetch('documentNumber'),
      'source_pdf_sha256' => result.fetch('sourcePdfSha256'),
      'status' => 'pending',
      'created_at' => Time.current.utc.iso8601,
      'expires_at' => result.fetch('expiresAt')
    }
    @submitter.qualified_signature_state = 'ticketed'
    @submitter.qualified_signature_public_id = result.fetch('publicId')
    @submitter.qualified_signature_source_sha256 = result.fetch('sourcePdfSha256')
    @submitter.qualified_signature_signed_sha256 = nil
    @submitter.qualified_signature_receipt = {}
    @submitter.qualified_signature_completed_at = nil
    @submitter.save!
    SubmissionEvents.create_with_tracking_data(
      @submitter,
      'start_qualified_signature',
      request,
      { public_id: result.fetch('publicId'), source_pdf_sha256: result.fetch('sourcePdfSha256') }
    )
  end
end
