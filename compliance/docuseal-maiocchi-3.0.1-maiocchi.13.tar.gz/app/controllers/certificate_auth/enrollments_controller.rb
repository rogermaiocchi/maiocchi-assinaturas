# frozen_string_literal: true

module CertificateAuth
  class EnrollmentsController < BaseController
    skip_forgery_protection only: %i[present complete]

    before_action :ensure_app_host!, only: %i[create complete]
    before_action :ensure_certificate_host!, only: :present
    before_action :ensure_feature_enabled!
    before_action :authenticate_user!, only: %i[create complete]

    def create
      _challenge, raw_state = CertificateAuthChallenge.issue!(purpose: 'enrollment', user: current_user)

      render_handoff(
        destination: certificate_auth_enrollment_present_url(host: certificate_host, protocol: 'https'),
        token_name: 'state',
        handoff_code: raw_state,
        button_text: 'Vincular certificado conectado',
        explanation: 'Confirme o certificado que será vinculado exclusivamente ao seu usuário.'
      )
    end

    def present
      challenge = find_challenge_by_state!('enrollment')
      client_certificate = read_client_certificate!
      raw_callback = nil

      CertificateAuthChallenge.transaction do
        challenge.lock!
        raise CertificateAuth::FlowError unless challenge.presentable? && challenge.user_id.present?

        raw_callback = challenge.verify_certificate!(client_certificate)
      end

      render_handoff(
        destination: certificate_auth_enrollment_complete_url(host: app_host, protocol: 'https'),
        token_name: 'callback_token',
        handoff_code: raw_callback,
        button_text: 'Confirmar vínculo',
        explanation: 'O certificado foi validado pelo canal mTLS. Confirme o vínculo na sua sessão autenticada.'
      )
    end

    def complete
      challenge = find_challenge_by_callback!('enrollment')
      conflict = false

      CertificateAuthChallenge.transaction do
        challenge.lock!
        raise CertificateAuth::FlowError unless challenge.completable? && challenge.user_id == current_user.id

        identity = CertificateIdentity.lock.find_by(sha256: challenge.certificate_sha256)

        if identity && identity.user_id != current_user.id
          conflict = true
        else
          identity ||= current_user.certificate_identities.new
          identity.assign_attributes(challenge.identity_attributes)
          identity.save!
        end

        challenge.consume!
      end

      return render_safe_error('Este certificado já está vinculado a outro usuário.', status: :conflict) if conflict

      redirect_to settings_profile_index_path, notice: 'Certificado digital vinculado com segurança.'
    rescue ActiveRecord::RecordNotUnique
      render_safe_error('Este certificado já possui um vínculo.', status: :conflict)
    end
  end
end
