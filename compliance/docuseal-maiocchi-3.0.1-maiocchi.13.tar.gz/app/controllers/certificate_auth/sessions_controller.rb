# frozen_string_literal: true

module CertificateAuth
  class SessionsController < BaseController
    skip_forgery_protection only: %i[present complete]

    before_action :ensure_app_host!, only: %i[create complete]
    before_action :ensure_certificate_host!, only: :present
    before_action :ensure_feature_enabled!

    def create
      challenge, raw_state = CertificateAuthChallenge.issue!(purpose: 'login')
      session[:certificate_auth_login_challenge_id] = challenge.id

      render_handoff(
        destination: certificate_auth_login_present_url(host: certificate_host, protocol: 'https'),
        token_name: 'state',
        handoff_code: raw_state,
        button_text: 'Apresentar certificado digital',
        explanation: 'Seu navegador solicitará o certificado conectado. Nenhuma senha do token é enviada ao portal.'
      )
    end

    def present
      challenge = find_challenge_by_state!('login')
      client_certificate = read_client_certificate!
      raw_callback = nil

      CertificateAuthChallenge.transaction do
        challenge.lock!
        raise CertificateAuth::FlowError unless challenge.presentable?

        raw_callback = challenge.verify_certificate!(client_certificate)
      end

      render_handoff(
        destination: certificate_auth_login_complete_url(host: app_host, protocol: 'https'),
        token_name: 'callback_token',
        handoff_code: raw_callback,
        button_text: 'Concluir acesso seguro',
        explanation: 'Certificado reconhecido. Retorne à área dos advogados para concluir o acesso.'
      )
    end

    def complete
      challenge = find_challenge_by_callback!('login')
      raise CertificateAuth::FlowError unless session[:certificate_auth_login_challenge_id] == challenge.id

      identity = nil

      CertificateAuthChallenge.transaction do
        challenge.lock!
        raise CertificateAuth::FlowError unless challenge.completable?

        identity = CertificateIdentity.lock.find_by(sha256: challenge.certificate_sha256)
        challenge.consume!

        if identity&.valid_now? && identity.user.active_for_authentication?
          identity.update!(last_used_at: Time.current)
        else
          identity = nil
        end
      end

      session.delete(:certificate_auth_login_challenge_id)

      unless identity
        return render_safe_error(
          'Este certificado não está vinculado a um usuário ativo.',
          status: :forbidden
        )
      end

      user = identity.user
      reset_session
      sign_in(:user, user)
      redirect_to dashboard_index_path, notice: 'Acesso realizado com certificado digital.'
    end
  end
end
