# frozen_string_literal: true

module CertificateAuth
  class BaseController < ApplicationController
    layout 'certificate_auth'

    skip_authorization_check
    skip_before_action :authenticate_user!
    skip_before_action :maybe_redirect_to_setup

    rescue_from CertificateAuth::FlowError, ActiveRecord::RecordNotFound do
      render_safe_error('Esta solicitação é inválida, expirou ou já foi utilizada.', status: :unprocessable_content)
    end

    rescue_from ActiveRecord::RecordInvalid do
      render_safe_error('Não foi possível concluir a autenticação com certificado.', status: :unprocessable_content)
    end

    private

    def ensure_feature_enabled!
      return if CertificateAuth::Configuration.enabled?

      render_safe_error('O acesso por certificado digital ainda não está disponível.', status: :service_unavailable)
    end

    def ensure_app_host!
      return head :not_found unless request.host.downcase == app_host

      head :not_found if forwarded_certificate_header.present?
    end

    def ensure_certificate_host!
      return head :not_found unless request.host.downcase == certificate_host

      raise CertificateAuth::FlowError unless request.ssl?
      raise CertificateAuth::FlowError if forwarded_certificate_header.blank?
    end

    def certificate_host
      CertificateAuth::Configuration.certificate_host
    end

    def app_host
      CertificateAuth::Configuration.app_host
    end

    def forwarded_certificate_header
      request.headers['X-Forwarded-Tls-Client-Cert']
    end

    def read_client_certificate!
      CertificateAuth::ClientCertificate.from_forwarded_header(forwarded_certificate_header).tap do |certificate|
        raise CertificateAuth::FlowError unless certificate.temporally_valid?

        CertificateAuth::RevocationChecker.check!(certificate)
      end
    rescue ArgumentError
      raise CertificateAuth::FlowError
    end

    def find_challenge_by_state!(purpose)
      digest = CertificateAuthChallenge.digest(params.require(:state))

      CertificateAuthChallenge.find_by!(state_digest: digest).tap do |challenge|
        raise CertificateAuth::FlowError unless challenge.purpose == purpose
      end
    end

    def find_challenge_by_callback!(purpose)
      CertificateAuthChallenge.find_by!(
        callback_digest: CertificateAuthChallenge.digest(params.require(:callback_token))
      ).tap do |challenge|
        raise CertificateAuth::FlowError unless challenge.purpose == purpose
      end
    end

    def render_handoff(destination:, token_name:, handoff_code:, button_text:, explanation:)
      render 'certificate_auth/handoff', locals: {
        destination:,
        token_name:,
        handoff_code:,
        button_text:,
        explanation:
      }
    end

    def render_safe_error(message, status:)
      render 'certificate_auth/error', locals: { message: }, status:
    end
  end
end
