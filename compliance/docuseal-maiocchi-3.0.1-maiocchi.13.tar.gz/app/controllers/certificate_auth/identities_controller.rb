# frozen_string_literal: true

module CertificateAuth
  class IdentitiesController < BaseController
    before_action :ensure_app_host!
    before_action :ensure_feature_enabled!
    before_action :authenticate_user!

    def destroy
      current_user.certificate_identities.find(params[:id]).revoke!

      redirect_to settings_profile_index_path, notice: 'Certificado digital revogado para acesso ao portal.'
    end
  end
end
