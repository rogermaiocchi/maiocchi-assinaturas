# frozen_string_literal: true

class EvidenceRecordsController < ApplicationController
  skip_before_action :maybe_redirect_to_setup
  skip_before_action :authenticate_user!
  skip_authorization_check

  def show
    submission = find_submission
    return head :not_found unless submission

    render json: MaiocchiEvidenceRecord.call(submission), status: :ok
  rescue PrivateEvidenceComposer::Error
    render json: {
      error: { message: 'A prova criptográfica do documento não pôde ser confirmada.' }
    }, status: :service_unavailable
  end

  private

  def find_submission
    MaiocchiSignaturePolicy.find_completed_by_public_id(params[:code])
  end
end
