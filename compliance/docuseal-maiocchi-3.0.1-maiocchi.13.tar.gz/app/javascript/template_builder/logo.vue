<template>
  <span
    class="maiocchi-mark"
    style="--mark-width: 40px; --mark-height: 40px"
    aria-hidden="true"
  >m<span class="maiocchi-dot">.</span></span>
</template>

<script>
export default {
  name: 'ProjectLogo'
}
</script>
