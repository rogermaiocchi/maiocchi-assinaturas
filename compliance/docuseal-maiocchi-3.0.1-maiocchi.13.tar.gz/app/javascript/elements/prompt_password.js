export default class extends HTMLElement {
  async connectedCallback () {
    const input = document.createElement('input')
    const password = await window.MaiocchiDialog.prompt('Digite a senha do PDF', {
      title: 'PDF protegido',
      inputType: 'password'
    })

    if (password === null) {
      this.remove()

      return
    }

    input.type = 'hidden'
    input.name = 'password'
    input.value = password

    this.form.append(input)

    this.form.requestSubmit()

    this.remove()
  }

  get form () {
    return this.closest('form')
  }
}
