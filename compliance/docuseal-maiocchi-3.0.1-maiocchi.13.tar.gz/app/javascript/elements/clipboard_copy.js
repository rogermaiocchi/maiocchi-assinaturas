export default class extends HTMLElement {
  connectedCallback () {
    this.clearChecked()

    this.addEventListener('click', (e) => {
      const text = this.dataset.text || this.innerText.trim()

      if (navigator.clipboard) {
        navigator.clipboard.writeText(text)
      } else {
        if (e.target.tagName !== 'INPUT') {
          alert('Não foi possível copiar. Confirme que o portal está aberto por HTTPS e tente novamente.')
        }
      }
    })
  }

  clearChecked () {
    this.querySelectorAll('input').forEach((e) => {
      e.checked = false
    })
  }
}
