# frozen_string_literal: true

class CertificateAuthChallenge < ApplicationRecord
  LIFETIME = 120.seconds
  RETENTION_GRACE_PERIOD = 0.seconds
  PURPOSES = %w[login enrollment].freeze
  TOKEN_BYTES = 32

  belongs_to :user, optional: true

  validates :purpose, inclusion: { in: PURPOSES }
  validates :state_digest, presence: true, uniqueness: true, format: { with: /\A\h{64}\z/ }
  validates :callback_digest, uniqueness: true, allow_nil: true, format: { with: /\A\h{64}\z/ }
  validates :expires_at, presence: true
  validate :enrollment_has_user

  def self.issue!(purpose:, user: nil)
    raw_state = generate_token
    challenge = create!(purpose:, user:, state_digest: digest(raw_state), expires_at: LIFETIME.from_now)

    [challenge, raw_state]
  end

  def self.digest(raw_token)
    Digest::SHA256.hexdigest(raw_token.to_s)
  end

  def self.generate_token
    SecureRandom.urlsafe_base64(TOKEN_BYTES, false)
  end

  def self.prune_expired!(before: RETENTION_GRACE_PERIOD.ago, limit: 1_000)
    raise ArgumentError, 'before must be a time' unless before.respond_to?(:to_time)
    raise ArgumentError, 'limit must be positive' unless limit.is_a?(Integer) && limit.positive?

    ids = where(expires_at: ...before).order(:expires_at, :id).limit(limit).pluck(:id)
    where(id: ids).delete_all
  end

  def presentable?(at: Time.current)
    consumed_at.nil? && verified_at.nil? && expires_at >= at
  end

  def completable?(at: Time.current)
    consumed_at.nil? && verified_at.present? && callback_digest.present? && expires_at >= at
  end

  def verify_certificate!(client_certificate)
    raise ActiveRecord::RecordInvalid, self unless presentable?

    raw_callback = self.class.generate_token
    update!(client_certificate.attributes_for_challenge.merge(
              callback_digest: self.class.digest(raw_callback),
              verified_at: Time.current
            ))
    raw_callback
  end

  def consume!
    raise ActiveRecord::RecordInvalid, self unless completable?

    update!(consumed_at: Time.current)
  end

  def identity_attributes
    {
      sha256: certificate_sha256,
      issuer_summary: certificate_issuer_summary,
      serial_number: certificate_serial_number,
      subject_summary: certificate_subject_summary,
      not_before: certificate_not_before,
      not_after: certificate_not_after,
      status: 'active'
    }
  end

  private

  def enrollment_has_user
    errors.add(:user, 'é obrigatório para vínculo') if purpose == 'enrollment' && user.blank?
  end
end
