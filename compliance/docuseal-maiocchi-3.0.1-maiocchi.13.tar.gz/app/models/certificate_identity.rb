# frozen_string_literal: true

class CertificateIdentity < ApplicationRecord
  STATUSES = %w[active revoked].freeze

  belongs_to :user

  validates :sha256, presence: true, uniqueness: true, format: { with: /\A\h{64}\z/ }
  validates :issuer_summary, :serial_number, :subject_summary, :not_before, :not_after, presence: true
  validates :status, inclusion: { in: STATUSES }
  validate :validity_period_is_ordered

  scope :active, -> { where(status: 'active') }

  def valid_now?(at: Time.current)
    status == 'active' && not_before <= at && not_after >= at
  end

  def revoke!
    update!(status: 'revoked')
  end

  private

  def validity_period_is_ordered
    return if not_before.blank? || not_after.blank? || not_before < not_after

    errors.add(:not_after, 'deve ser posterior ao início da validade')
  end
end
