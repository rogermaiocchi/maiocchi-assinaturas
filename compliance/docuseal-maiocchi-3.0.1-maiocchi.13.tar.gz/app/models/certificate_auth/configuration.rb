# frozen_string_literal: true

module CertificateAuth
  module Configuration
    DEFAULT_CERTIFICATE_HOST = 'certificado.assinatura.maiocchi.adv.br'
    DEFAULT_APP_HOST = 'documentos.assinatura.maiocchi.adv.br'

    module_function

    def enabled?
      ActiveModel::Type::Boolean.new.cast(ENV.fetch('CERTIFICATE_AUTH_ENABLED', 'false')) && revocation_ready?
    end

    def revocation_ready?
      trust_bundle_file.present? && File.readable?(trust_bundle_file)
    end

    def trust_bundle_file
      ENV['CERTIFICATE_AUTH_TRUST_BUNDLE_FILE'].presence
    end

    def certificate_host
      ENV.fetch('CERTIFICATE_AUTH_HOST', DEFAULT_CERTIFICATE_HOST).to_s.downcase
    end

    def app_host
      ENV.fetch('CERTIFICATE_AUTH_APP_HOST', DEFAULT_APP_HOST).to_s.downcase
    end
  end
end
