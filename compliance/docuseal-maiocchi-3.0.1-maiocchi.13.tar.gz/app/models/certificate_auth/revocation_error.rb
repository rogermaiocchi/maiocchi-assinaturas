# frozen_string_literal: true

module CertificateAuth
  class RevocationError < FlowError; end
end
