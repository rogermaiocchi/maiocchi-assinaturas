# frozen_string_literal: true

require 'base64'
require 'cgi'
require 'openssl'

module CertificateAuth
  class ClientCertificate
    MAX_HEADER_BYTES = 32.kilobytes
    SUMMARY_FIELDS = %w[CN O OU].freeze

    attr_reader :certificate

    delegate :not_before, :not_after, to: :certificate

    def self.from_forwarded_header(value)
      encoded = value.to_s
      raise ArgumentError, 'missing certificate' if encoded.blank?
      raise ArgumentError, 'certificate header is too large' if encoded.bytesize > MAX_HEADER_BYTES

      new(parse_forwarded_certificate(encoded))
    end

    def initialize(certificate)
      @certificate = certificate
    end

    def sha256
      Digest::SHA256.hexdigest(certificate.to_der)
    end

    def issuer_summary
      summarize(certificate.issuer)
    end

    def serial_number
      certificate.serial.to_s(16).upcase.encode(Encoding::UTF_8)
    end

    def subject_summary
      summarize(certificate.subject)
    end

    def temporally_valid?(at: Time.current)
      at.between?(not_before, not_after)
    end

    def attributes_for_challenge
      {
        certificate_sha256: sha256,
        certificate_issuer_summary: issuer_summary,
        certificate_serial_number: serial_number,
        certificate_subject_summary: subject_summary,
        certificate_not_before: not_before,
        certificate_not_after: not_after
      }
    end

    private

    def self.parse_forwarded_certificate(encoded)
      decoded = decode_percent_escapes_preserving_plus(encoded).gsub('\\n', "\n")
      pem = decoded[/-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----/m]

      return OpenSSL::X509::Certificate.new(pem) if pem

      raw_certificate = decoded.split(',', 2).first.to_s.strip
      base64_candidates(raw_certificate).each do |candidate|
        return OpenSSL::X509::Certificate.new(Base64.strict_decode64(candidate))
      rescue ArgumentError, OpenSSL::X509::CertificateError
        next
      end

      raise OpenSSL::X509::CertificateError
    rescue OpenSSL::X509::CertificateError
      raise ArgumentError, 'invalid certificate'
    end

    def self.decode_percent_escapes_preserving_plus(encoded)
      return encoded unless encoded.include?('%')

      CGI.unescape(encoded.gsub('+', '%2B'))
         .gsub('-----BEGIN+CERTIFICATE-----', '-----BEGIN CERTIFICATE-----')
         .gsub('-----END+CERTIFICATE-----', '-----END CERTIFICATE-----')
    end

    def self.base64_candidates(value)
      [
        value.gsub(/\s+/, ''),
        value.tr(' ', '+').gsub(/[\r\n\t]/, '')
      ].uniq.compact_blank
    end

    private_class_method :parse_forwarded_certificate,
                         :decode_percent_escapes_preserving_plus,
                         :base64_candidates

    def summarize(name)
      name.to_a.filter_map do |entry, value, _type|
        next unless SUMMARY_FIELDS.include?(entry)

        key = entry.to_s.dup.force_encoding(Encoding::UTF_8).scrub
        normalized = value.to_s.dup.force_encoding(Encoding::UTF_8).scrub
        "#{key}=#{normalized.gsub(/[\r\n]/, ' ').strip}"
      end.join(', ').encode(Encoding::UTF_8).first(500).presence || 'Não informado'
    end
  end
end
