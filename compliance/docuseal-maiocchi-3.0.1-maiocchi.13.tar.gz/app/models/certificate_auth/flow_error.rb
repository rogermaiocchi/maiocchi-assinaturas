# frozen_string_literal: true

module CertificateAuth
  class FlowError < StandardError; end
end
