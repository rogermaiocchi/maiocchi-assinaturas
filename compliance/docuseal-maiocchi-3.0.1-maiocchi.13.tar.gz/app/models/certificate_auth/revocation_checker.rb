# frozen_string_literal: true

require 'ipaddr'
require 'net/http'
require 'openssl'
require 'resolv'

module CertificateAuth
  class RevocationChecker
    CACHE_TTL = 5.minutes
    CLOCK_SKEW_SECONDS = 300
    MAX_CHAIN_DEPTH = 8
    MAX_CERTIFICATE_BYTES = 1.megabyte
    MAX_OCSP_BYTES = 1.megabyte
    MAX_CRL_BYTES = 16.megabytes
    MAX_OCSP_AGE_SECONDS = 7.days.to_i

    class SafeHttp
      BLOCKED_NETWORKS = %w[
        0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16
        172.16.0.0/12 192.0.0.0/24 192.0.2.0/24 192.168.0.0/16 198.18.0.0/15
        198.51.100.0/24 203.0.113.0/24 224.0.0.0/4 240.0.0.0/4
        ::/128 ::1/128 fc00::/7 fe80::/10 ff00::/8 2001:db8::/32
      ].map { |network| IPAddr.new(network) }.freeze

      def fetch(uri_value, max_bytes:, method: :get, body: nil, headers: {})
        uri = URI.parse(uri_value.to_s)
        validate_uri!(uri)
        addresses = Addrinfo.getaddrinfo(uri.host, uri.port, nil, :STREAM).map(&:ip_address).uniq
        raise RevocationError, 'revocation endpoint did not resolve' if addresses.empty?

        addresses.each { |address| validate_public_address!(address) }
        http = Net::HTTP.new(uri.host, uri.port, nil)
        http.ipaddr = addresses.first
        http.use_ssl = uri.scheme == 'https'
        http.verify_mode = OpenSSL::SSL::VERIFY_PEER if http.use_ssl?
        http.open_timeout = 3
        http.read_timeout = 5
        http.write_timeout = 5
        request = method == :post ? Net::HTTP::Post.new(uri.request_uri) : Net::HTTP::Get.new(uri.request_uri)
        headers.each { |name, value| request[name] = value }
        request.body = body if body
        read_response(http, request, max_bytes)
      rescue URI::InvalidURIError, SocketError, SystemCallError, Timeout::Error, OpenSSL::SSL::SSLError,
             Net::HTTPBadResponse, Net::HTTPHeaderSyntaxError => e
        raise RevocationError, "revocation endpoint unavailable: #{e.class}"
      end

      private

      def validate_uri!(uri)
        valid = %w[http https].include?(uri.scheme) && uri.host.present? && uri.userinfo.nil? &&
                uri.fragment.nil? && [80, 443].include?(uri.port)
        raise RevocationError, 'revocation endpoint URL is not allowed' unless valid
      end

      def validate_public_address!(value)
        address = IPAddr.new(value)
        if BLOCKED_NETWORKS.any? { |network| network.include?(address) }
          raise RevocationError, 'revocation endpoint address is not public'
        end
      rescue IPAddr::InvalidAddressError
        raise RevocationError, 'revocation endpoint address is invalid'
      end

      def read_response(http, request, max_bytes)
        bytes = +''
        http.request(request) do |response|
          unless response.is_a?(Net::HTTPSuccess)
            raise RevocationError, "revocation endpoint returned HTTP #{response.code}"
          end

          declared_size = response['content-length'].to_i
          raise RevocationError, 'revocation response is too large' if declared_size > max_bytes

          response.read_body do |chunk|
            bytes << chunk
            raise RevocationError, 'revocation response is too large' if bytes.bytesize > max_bytes
          end
        end
        bytes.b
      end
    end

    class << self
      def check!(client_certificate)
        Rails.cache.fetch("certificate-revocation-v1:#{client_certificate.sha256}", expires_in: CACHE_TTL) do
          checker.check!(client_certificate.certificate)
          true
        end
      end

      private

      def checker
        trust_bundle = CertificateAuth::Configuration.trust_bundle_file
        @checker = nil if defined?(@checker_path) && @checker_path != trust_bundle
        @checker_path = trust_bundle
        @checker ||= new(trust_bundle_file: trust_bundle)
      end
    end

    def initialize(trust_bundle_file:, http_client: SafeHttp.new, now: -> { Time.current })
      unless trust_bundle_file.present? && File.readable?(trust_bundle_file)
        raise RevocationError, 'ICP-Brasil trust bundle is unavailable'
      end

      @http_client = http_client
      @now = now
      @mutex = Mutex.new
      @trusted_certificates = parse_certificates(File.binread(trust_bundle_file))
      raise RevocationError, 'ICP-Brasil trust bundle is empty' if @trusted_certificates.empty?

      @store = OpenSSL::X509::Store.new
      @store.add_file(trust_bundle_file)
      @store.purpose = OpenSSL::X509::PURPOSE_SSL_CLIENT
      @store.time = @now.call
      @ocsp_store = OpenSSL::X509::Store.new
      @ocsp_store.add_file(trust_bundle_file)
      @ocsp_store.time = @now.call
    end

    def check!(certificate)
      @mutex.synchronize { check_without_lock!(certificate) }
    end

    private

    def check_without_lock!(certificate)
      chain = build_chain(certificate)
      unless @store.verify(certificate, chain)
        raise RevocationError, "certificate chain is not trusted: #{@store.error_string}"
      end

      issuer = chain.first
      raise RevocationError, 'certificate issuer is unavailable' unless issuer

      status = ocsp_status(certificate, issuer, chain)
      status = crl_status(certificate, issuer) if status == :unavailable
      raise RevocationError, 'certificate is revoked' if status == :revoked
      raise RevocationError, 'certificate revocation status is unavailable' unless status == :good

      true
    rescue RevocationError
      raise
    rescue OpenSSL::OpenSSLError, ArgumentError => e
      raise RevocationError, "certificate revocation validation failed: #{e.class}"
    end

    def build_chain(certificate)
      chain = []
      candidates = @trusted_certificates.dup
      current = certificate
      MAX_CHAIN_DEPTH.times do
        issuer = candidates.find { |candidate| issuer_for?(current, candidate) }
        unless issuer
          current.ca_issuer_uris.first(4).each do |uri|
            candidates.concat(parse_certificates(@http_client.fetch(uri, max_bytes: MAX_CERTIFICATE_BYTES)))
          rescue RevocationError
            next
          end
          issuer = candidates.find { |candidate| issuer_for?(current, candidate) }
        end
        raise RevocationError, 'certificate chain is incomplete' unless issuer

        chain << issuer
        return chain if self_signed?(issuer)

        current = issuer
      end
      raise RevocationError, 'certificate chain exceeds the allowed depth'
    end

    def issuer_for?(certificate, candidate)
      certificate.issuer == candidate.subject && certificate.verify(candidate.public_key)
    rescue OpenSSL::OpenSSLError
      false
    end

    def self_signed?(certificate)
      certificate.subject == certificate.issuer && certificate.verify(certificate.public_key)
    end

    def ocsp_status(certificate, issuer, chain)
      cert_id = OpenSSL::OCSP::CertificateId.new(certificate, issuer)
      request = OpenSSL::OCSP::Request.new
      request.add_certid(cert_id)
      certificate.ocsp_uris.first(4).each do |uri|
        body = @http_client.fetch(
          uri,
          max_bytes: MAX_OCSP_BYTES,
          method: :post,
          body: request.to_der,
          headers: { 'Content-Type' => 'application/ocsp-request', 'Accept' => 'application/ocsp-response' }
        )
        response = OpenSSL::OCSP::Response.new(body)
        next unless response.status == OpenSSL::OCSP::RESPONSE_STATUS_SUCCESSFUL

        basic = response.basic
        next unless basic&.verify(chain, @ocsp_store, 0)

        single = basic.find_response(cert_id)
        next unless single&.check_validity(CLOCK_SKEW_SECONDS, MAX_OCSP_AGE_SECONDS)

        return :good if single.cert_status == OpenSSL::OCSP::V_CERTSTATUS_GOOD
        return :revoked if single.cert_status == OpenSSL::OCSP::V_CERTSTATUS_REVOKED
      rescue RevocationError, OpenSSL::OpenSSLError
        next
      end
      :unavailable
    end

    def crl_status(certificate, issuer)
      certificate.crl_uris.first(4).each do |uri|
        body = @http_client.fetch(uri, max_bytes: MAX_CRL_BYTES)
        crl = OpenSSL::X509::CRL.new(body)
        next unless crl.verify(issuer.public_key)
        next unless crl.last_update && crl.next_update
        next if crl.last_update > now + CLOCK_SKEW_SECONDS
        next if crl.next_update < now - CLOCK_SKEW_SECONDS

        return :revoked if crl.revoked.any? { |entry| entry.serial == certificate.serial }

        return :good
      rescue RevocationError, OpenSSL::OpenSSLError
        next
      end
      :unavailable
    end

    def now
      @now.call
    end

    def parse_certificates(bytes)
      pem_certificates = bytes.scan(/-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----/m)
      return pem_certificates.map { |pem| OpenSSL::X509::Certificate.new(pem) } if pem_certificates.any?

      [OpenSSL::X509::Certificate.new(bytes)]
    rescue OpenSSL::X509::CertificateError
      begin
        OpenSSL::PKCS7.new(bytes).certificates || []
      rescue OpenSSL::PKCS7::PKCS7Error
        []
      end
    end
  end
end
