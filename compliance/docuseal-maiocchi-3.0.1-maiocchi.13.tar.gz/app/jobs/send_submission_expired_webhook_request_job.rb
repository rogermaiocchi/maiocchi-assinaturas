# frozen_string_literal: true

class SendSubmissionExpiredWebhookRequestJob
  include Sidekiq::Job

  sidekiq_options queue: :webhooks

  MAX_ATTEMPTS = 10

  def perform(params = {})
    submission = Submission.find_by(id: params['submission_id'])

    return unless submission

    webhook_url = WebhookUrl.find_by(id: params['webhook_url_id'])

    return unless webhook_url

    attempt = params['attempt'].to_i

    return if webhook_url.url.blank? || webhook_url.events.exclude?('submission.expired')

    resp = SendWebhookRequest.call(webhook_url, event_type: 'submission.expired',
                                                event_uuid: params['event_uuid'],
                                                record: submission,
                                                attempt:,
                                                data: Submissions::SerializeForApi.call(submission))

    return if attempt > MAX_ATTEMPTS || (resp && resp.status.to_i < 400)

    SendSubmissionExpiredWebhookRequestJob.perform_in((2**attempt).minutes, {
                                                        **params,
                                                        'attempt' => attempt + 1,
                                                        'last_status' => resp&.status.to_i
                                                      })
  end
end
