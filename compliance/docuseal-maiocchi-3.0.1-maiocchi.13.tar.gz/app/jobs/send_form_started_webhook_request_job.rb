# frozen_string_literal: true

class SendFormStartedWebhookRequestJob
  include Sidekiq::Job

  sidekiq_options queue: :webhooks

  MAX_ATTEMPTS = 10

  def perform(params = {})
    submitter = Submitter.find_by(id: params['submitter_id'])

    return unless submitter

    webhook_url = WebhookUrl.find_by(id: params['webhook_url_id'])

    return unless webhook_url

    attempt = params['attempt'].to_i

    return if webhook_url.url.blank? || webhook_url.events.exclude?('form.started')

    ActiveStorage::Current.url_options = Docuseal.default_url_options

    resp = SendWebhookRequest.call(webhook_url, event_type: 'form.started',
                                                event_uuid: params['event_uuid'],
                                                record: submitter,
                                                attempt:,
                                                data: Submitters::SerializeForWebhook.call(submitter))

    return if attempt > MAX_ATTEMPTS || (resp && resp.status.to_i < 400)

    SendFormStartedWebhookRequestJob.perform_in((2**attempt).minutes, {
                                                  **params,
                                                  'attempt' => attempt + 1,
                                                  'last_status' => resp&.status.to_i
                                                })
  end
end
