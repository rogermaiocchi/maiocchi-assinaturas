# frozen_string_literal: true

class QualifiedSignaturesController < ApplicationController
  before_action { authorize!(:create, Template) }
  before_action :ensure_remote_available

  def new; end

  def create
    upload = params[:pdf]
    raise PrivatePadesTickets::Error, 'Selecione o PDF que será assinado.' unless upload.respond_to?(:read)

    result = PrivatePadesTickets.create(
      pdf: BoundedPdfUpload.read!(upload, max_bytes: PrivatePadesTickets::MAX_PDF_BYTES),
      document_name: upload.original_filename,
      intended_for: params[:intended_for],
      purpose: params[:purpose]
    )

    redirect_to PrivatePadesTickets.local_ticket_path(result.fetch('url'))
  rescue PrivatePadesTickets::Error, BoundedPdfUpload::TooLarge => e
    flash.now[:alert] = e.message
    render :new, status: :unprocessable_content
  end

  private

  def ensure_remote_available
    return if PrivatePadesTickets.remote_available?

    alert = 'A assinatura qualificada está indisponível porque nenhum PSC credenciado está conectado ao gateway.'
    redirect_to root_path, alert:
  end
end
