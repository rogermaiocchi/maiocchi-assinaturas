self.addEventListener('install', () => {
  console.log('Maiocchi Assinaturas instalado')
})

self.addEventListener('activate', () => {
  console.log('Maiocchi Assinaturas ativado')
})

self.addEventListener('fetch', (event) => {
  event.respondWith(fetch(event.request))
})
