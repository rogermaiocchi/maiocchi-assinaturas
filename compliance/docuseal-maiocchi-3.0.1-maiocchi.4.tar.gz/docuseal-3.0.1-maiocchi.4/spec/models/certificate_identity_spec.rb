# frozen_string_literal: true

RSpec.describe CertificateIdentity do
  it 'accepts an active certificate inside its validity period' do
    identity = build(:certificate_identity)

    expect(identity).to be_valid_now
  end

  it 'rejects a revoked or expired certificate for login' do
    revoked = build(:certificate_identity, status: 'revoked')
    expired = build(:certificate_identity, not_before: 2.years.ago, not_after: 1.year.ago)

    expect(revoked).not_to be_valid_now
    expect(expired).not_to be_valid_now
  end
end
