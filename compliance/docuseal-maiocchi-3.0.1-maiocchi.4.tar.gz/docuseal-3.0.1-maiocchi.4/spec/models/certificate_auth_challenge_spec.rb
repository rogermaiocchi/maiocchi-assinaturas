# frozen_string_literal: true

RSpec.describe CertificateAuthChallenge do
  describe '.issue!' do
    it 'stores only a SHA-256 digest and expires after 120 seconds' do
      freeze_time do
        challenge, raw_state = described_class.issue!(purpose: 'login')

        expect(challenge.state_digest).to eq(Digest::SHA256.hexdigest(raw_state))
        expect(challenge.attributes.values).not_to include(raw_state)
        expect(challenge.expires_at).to eq(120.seconds.from_now)
      end
    end

    it 'requires an authenticated user for enrollment' do
      expect do
        described_class.issue!(purpose: 'enrollment')
      end.to raise_error(ActiveRecord::RecordInvalid)
    end
  end
end
