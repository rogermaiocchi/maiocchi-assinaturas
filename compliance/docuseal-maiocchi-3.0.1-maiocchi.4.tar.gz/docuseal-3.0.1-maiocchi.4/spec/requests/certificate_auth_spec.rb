# frozen_string_literal: true

require 'cgi'

RSpec.describe 'Certificate authentication' do
  let(:app_host) { 'documentos.assinatura.maiocchi.adv.br' }
  let(:certificate_host) { 'certificado.assinatura.maiocchi.adv.br' }
  let(:user) { create(:user) }
  let(:valid_certificate) { build_certificate(not_before: 1.hour.ago, not_after: 1.year.from_now) }
  let(:expired_certificate) { build_certificate(not_before: 2.years.ago, not_after: 1.year.ago) }

  before do
    allow(CertificateAuth::Configuration).to receive_messages(
      enabled?: true,
      app_host:,
      certificate_host:
    )
    host! app_host
  end

  it 'rejects a spoofed client certificate header on the application host' do
    post certificate_auth_login_start_path, headers: certificate_headers(valid_certificate)

    expect(response).to have_http_status(:not_found)
    expect(CertificateAuthChallenge.count).to eq(0)
  end

  it 'rejects certificate presentation on a host other than the dedicated mTLS host' do
    _challenge, state = CertificateAuthChallenge.issue!(purpose: 'login')

    post certificate_auth_login_present_path,
         params: { state: }, headers: certificate_headers(valid_certificate)

    expect(response).to have_http_status(:not_found)
  end

  it 'rejects an expired certificate' do
    _challenge, state = CertificateAuthChallenge.issue!(purpose: 'login')
    host! certificate_host

    post certificate_auth_login_present_path,
         params: { state: }, headers: certificate_headers(expired_certificate)

    expect(response).to have_http_status(:unprocessable_content)
    expect(CertificateAuthChallenge.last.verified_at).to be_nil
  end

  it 'consumes both presentation state and callback token only once' do
    certificate = valid_certificate
    create_identity(user, certificate)
    host! app_host
    post certificate_auth_login_start_path
    state = hidden_value('state')
    host! certificate_host

    post certificate_auth_login_present_path,
         params: { state: }, headers: certificate_headers(certificate)
    callback_code = hidden_value('callback_token')

    post certificate_auth_login_present_path,
         params: { state: }, headers: certificate_headers(certificate)
    expect(response).to have_http_status(:unprocessable_content)

    host! app_host
    post certificate_auth_login_complete_path, params: callback_params(callback_code)
    expect(response).to redirect_to(root_path)

    post certificate_auth_login_complete_path, params: callback_params(callback_code)
    expect(response).to have_http_status(:unprocessable_content)
  end

  it 'returns a safe error for an unlinked certificate and consumes the callback' do
    callback_code = present_login(valid_certificate)

    host! app_host
    post certificate_auth_login_complete_path, params: callback_params(callback_code)

    expect(response).to have_http_status(:forbidden)
    expect(response.body).to include('não está vinculado a um usuário ativo')
    expect(response.body).not_to include(valid_certificate.subject.to_s)
    expect(CertificateAuthChallenge.last.consumed_at).to be_present
  end

  it 'enrolls a certificate only for the user in the authenticated challenge, then logs in with it' do
    host! app_host
    sign_in user

    post certificate_auth_enrollment_start_path
    state = hidden_value('state')

    host! certificate_host
    post certificate_auth_enrollment_present_path,
         params: { state: }, headers: certificate_headers(valid_certificate)
    enrollment_code = hidden_value('callback_token')

    host! app_host
    post certificate_auth_enrollment_complete_path, params: callback_params(enrollment_code)

    expect(response).to redirect_to(settings_profile_index_path)
    identity = user.certificate_identities.reload.sole
    expect(identity.sha256).to eq(Digest::SHA256.hexdigest(valid_certificate.to_der))

    sign_out user
    login_code = present_login(valid_certificate)
    host! app_host
    post certificate_auth_login_complete_path, params: callback_params(login_code)

    expect(response).to redirect_to(root_path)
    expect(identity.reload.last_used_at).to be_present
  end

  it 'does not permit a different authenticated user to complete an enrollment challenge' do
    host! app_host
    sign_in user
    post certificate_auth_enrollment_start_path
    state = hidden_value('state')

    host! certificate_host
    post certificate_auth_enrollment_present_path,
         params: { state: }, headers: certificate_headers(valid_certificate)
    callback_code = hidden_value('callback_token')

    host! app_host
    sign_out user
    sign_in create(:user)
    post certificate_auth_enrollment_complete_path, params: callback_params(callback_code)

    expect(response).to have_http_status(:unprocessable_content)
    expect(CertificateIdentity.count).to eq(0)
  end

  private

  def callback_params(code)
    { %i[callback token].join('_') => code }
  end

  def present_login(certificate)
    host! app_host
    post certificate_auth_login_start_path
    state = hidden_value('state')
    host! certificate_host
    post certificate_auth_login_present_path,
         params: { state: }, headers: certificate_headers(certificate)
    hidden_value('callback_token')
  end

  def create_identity(identity_user, certificate)
    parsed = CertificateAuth::ClientCertificate.new(certificate)
    create(:certificate_identity,
           user: identity_user,
           sha256: parsed.sha256,
           issuer_summary: parsed.issuer_summary,
           serial_number: parsed.serial_number,
           subject_summary: parsed.subject_summary,
           not_before: parsed.not_before,
           not_after: parsed.not_after)
  end

  def hidden_value(name)
    Nokogiri::HTML5(response.body).at_css("input[name='#{name}']")['value']
  end

  def certificate_headers(certificate)
    {
      'HTTPS' => 'on',
      'X-Forwarded-Proto' => 'https',
      'X-Forwarded-Tls-Client-Cert' => CGI.escape(certificate.to_pem)
    }
  end

  def build_certificate(not_before:, not_after:)
    key = OpenSSL::PKey::EC.generate('prime256v1')
    certificate = OpenSSL::X509::Certificate.new
    certificate.version = 2
    certificate.serial = SecureRandom.random_number(2**64)
    certificate.subject = OpenSSL::X509::Name.parse('/CN=Usuário de Teste/O=Maiocchi')
    certificate.issuer = OpenSSL::X509::Name.parse('/CN=AC de Teste/O=ICP-Brasil')
    certificate.public_key = key
    certificate.not_before = not_before
    certificate.not_after = not_after
    certificate.sign(key, OpenSSL::Digest.new('SHA256'))
    certificate
  end
end
