# frozen_string_literal: true

RSpec.describe 'Maiocchi portal branding' do
  before do
    create(:user)
    host! 'documentos.assinatura.maiocchi.adv.br'
  end

  it 'renders the lawyer access page in the institutional identity' do
    get new_user_session_path

    expect(response).to have_http_status(:ok)
    expect(response.body).to include('Roger Maiocchi, advogado')
    expect(response.body).to include('roger@maiocchi.adv.br')
    expect(response.body).to include('Acesso com certificado digital')
    expect(response.body).to include('Acesso com usuário e senha')
    expect(response.body.index('Acesso com certificado digital'))
      .to be < response.body.index('Acesso com usuário e senha')
    expect(response.body).to include('Tecnologia de código aberto DocuSeal')
    expect(response.body).not_to include('contato@maiocchi.adv.br')
    expect(response.body).not_to include('Maiocchi Advocacia')
  end

  it 'forces Brazilian Portuguese and the exact institutional account name' do
    account = Account.new

    expect(account.locale).to eq('pt')
    expect(account.name).to eq('Roger Maiocchi, advogado')
    expect(AccountsController::LOCALE_OPTIONS).to eq('pt' => 'Português (Brasil)')
  end
end
