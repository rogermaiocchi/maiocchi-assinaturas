# frozen_string_literal: true

FactoryBot.define do
  factory :certificate_identity do
    user
    sha256 { Digest::SHA256.hexdigest(SecureRandom.hex(16)) }
    issuer_summary { 'CN=Autoridade Certificadora de Teste' }
    serial_number { SecureRandom.hex(8).upcase }
    subject_summary { 'CN=Usuário de Teste' }
    not_before { 1.day.ago }
    not_after { 1.year.from_now }
    status { 'active' }
  end
end
