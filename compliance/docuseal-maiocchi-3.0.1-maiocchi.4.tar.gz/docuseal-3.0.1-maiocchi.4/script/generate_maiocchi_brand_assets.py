#!/usr/bin/env python3
"""Generate raster Maiocchi brand icons from the typographic m. mark."""

import os
import shutil
import subprocess
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "public"
INK = "#0a0a0a"
PAPER = "#f6f5f1"
ACCENT = "#ffc400"
FONT_QUERIES = (
    "Arial Black",
    "Arial:style=Bold",
    "DejaVu Sans:style=Bold",
    "Liberation Sans:style=Bold",
)
FONT_FILENAMES = ("DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf", "Arial Bold.ttf", "Arial.ttf")


@lru_cache(maxsize=1)
def discover_font() -> str | None:
    """Find a bold sans-serif font without assuming an operating-system path."""
    override = os.environ.get("MAIOCCHI_FONT_FILE")
    if override and Path(override).expanduser().is_file():
        return str(Path(override).expanduser())

    fc_match = shutil.which("fc-match")
    if fc_match:
        for query in FONT_QUERIES:
            result = subprocess.run(
                [fc_match, "--format=%{file}", query],
                check=False,
                capture_output=True,
                text=True,
            )
            candidate = result.stdout.strip()
            if result.returncode == 0 and candidate and Path(candidate).is_file():
                return candidate

    for filename in FONT_FILENAMES:
        try:
            ImageFont.truetype(filename, size=16)
        except OSError:
            continue
        return filename

    return None


def font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    discovered = discover_font()
    if discovered:
        return ImageFont.truetype(discovered, size=size)

    try:
        return ImageFont.load_default(size=size)
    except TypeError as error:
        raise RuntimeError("Pillow 10.1+ or a discoverable TrueType font is required") from error


def icon(size: int) -> Image.Image:
    scale = 4
    canvas_size = size * scale
    image = Image.new("RGB", (canvas_size, canvas_size), PAPER)
    draw = ImageDraw.Draw(image)
    mark_font = font(round(canvas_size * 0.62))
    m_box = draw.textbbox((0, 0), "m", font=mark_font)
    dot_font = font(round(canvas_size * 0.58))
    dot_box = draw.textbbox((0, 0), ".", font=dot_font)
    gap = round(canvas_size * 0.005)
    total_width = (m_box[2] - m_box[0]) + (dot_box[2] - dot_box[0]) + gap
    x = round((canvas_size - total_width) / 2)
    baseline_y = round(canvas_size * 0.16)
    draw.text((x, baseline_y), "m", font=mark_font, fill=INK)
    draw.text((x + m_box[2] - m_box[0] + gap, baseline_y), ".", font=dot_font, fill=ACCENT)
    return image.resize((size, size), Image.Resampling.LANCZOS)


def maskable_icon(size: int) -> Image.Image:
    """Keep the m. mark inside the maskable-icon safe zone."""
    image = Image.new("RGB", (size, size), PAPER)
    mark_size = round(size * 0.68)
    mark = icon(mark_size)
    offset = (size - mark_size) // 2
    image.paste(mark, (offset, offset))
    return image


def preview() -> Image.Image:
    size = 800
    image = Image.new("RGB", (size, size), PAPER)
    draw = ImageDraw.Draw(image)
    mark = icon(220)
    image.paste(mark, ((size - 220) // 2, 110))
    title_font = font(58)
    body_font = font(27)
    title = "MAIOCCHI."
    title_box = draw.textbbox((0, 0), title, font=title_font)
    draw.text(((size - (title_box[2] - title_box[0])) / 2, 360), title[:-1], font=title_font, fill=INK)
    prefix_box = draw.textbbox((0, 0), title[:-1], font=title_font)
    draw.text(((size - (title_box[2] - title_box[0])) / 2 + prefix_box[2], 360), ".", font=title_font, fill=ACCENT)
    subtitle = "ASSINATURAS"
    subtitle_box = draw.textbbox((0, 0), subtitle, font=body_font)
    draw.text(((size - (subtitle_box[2] - subtitle_box[0])) / 2, 445), subtitle, font=body_font, fill=INK)
    office = "Roger Maiocchi, advogado"
    office_box = draw.textbbox((0, 0), office, font=body_font)
    draw.text(((size - (office_box[2] - office_box[0])) / 2, 505), office, font=body_font, fill="#68645d")
    draw.rounded_rectangle((180, 610, 620, 618), radius=4, fill=ACCENT)
    return image


def main() -> None:
    sizes = {
        16: "favicon-16x16.png",
        32: "favicon-32x32.png",
        96: "favicon-96x96.png",
        180: "apple-icon-180x180.png",
        192: "pwa-icon-192x192.png",
        512: "pwa-icon-512x512.png",
    }
    generated = {size: icon(size) for size in sizes}
    for size, filename in sizes.items():
        generated[size].save(PUBLIC / filename, optimize=True)
    generated[180].save(PUBLIC / "apple-touch-icon.png", optimize=True)
    generated[180].save(PUBLIC / "apple-touch-icon-precomposed.png", optimize=True)
    maskable_icon(512).save(PUBLIC / "pwa-icon-maskable-512x512.png", optimize=True)
    icon(256).save(PUBLIC / "favicon.ico", sizes=[(16, 16), (32, 32), (48, 48), (96, 96), (256, 256)])
    preview().save(PUBLIC / "preview.png", optimize=True)


if __name__ == "__main__":
    main()
