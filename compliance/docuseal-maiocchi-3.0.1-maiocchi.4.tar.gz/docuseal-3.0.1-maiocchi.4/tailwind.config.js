module.exports = {
  plugins: [
    require('daisyui')
  ],
  daisyui: {
    themes: [
      {
        maiocchi: {
          'color-scheme': 'light',
          primary: '#ffc400',
          secondary: '#0a0a0a',
          accent: '#ffc400',
          neutral: '#0a0a0a',
          'base-100': '#ffffff',
          'base-200': '#f6f5f1',
          'base-300': '#dedbd2',
          'base-content': '#0a0a0a',
          '--rounded-btn': '0.75rem',
          '--tab-border': '2px',
          '--tab-radius': '.75rem'
        }
      }
    ]
  }
}
