# frozen_string_literal: true

module MaiocchiBrand
  OFFICE_NAME = 'Roger Maiocchi, advogado'
  PRODUCT_NAME = 'Maiocchi Assinaturas'
  SUPPORT_EMAIL = 'roger@maiocchi.adv.br'
  HOME_URL = ENV.fetch('MAIOCCHI_HOME_URL', 'https://assinatura.maiocchi.adv.br')
  SOURCE_URL = ENV.fetch(
    'MAIOCCHI_SOURCE_URL',
    'https://github.com/rogermaiocchi/maiocchi-assinaturas/raw/refs/tags/portal-v1.13.1/compliance/docuseal-maiocchi-3.0.1-maiocchi.4.tar.gz'
  )
  LICENSE_URL = ENV.fetch(
    'MAIOCCHI_LICENSE_URL',
    'https://assinatura.maiocchi.adv.br/legal/LICENSE.txt'
  )

  COLORS = {
    ink: '#0a0a0a',
    paper: '#f6f5f1',
    accent: '#ffc400'
  }.freeze

  COPY = {
    product_tagline: 'Documentos organizados, assinaturas seguras e acompanhamento simples.',
    sign_in_title: 'Área dos advogados',
    sign_in_lead: 'Acesse o ambiente seguro do escritório para preparar e acompanhar documentos.',
    password_access: 'Acesso com usuário e senha',
    forgot_password_title: 'Recuperar acesso',
    forgot_password_lead: 'Fale com a administração do escritório para recuperar seu acesso com segurança.',
    change_password_title: 'Definir nova senha',
    change_password_lead: 'Escolha uma senha forte para proteger seu acesso ao escritório.',
    setup_title: 'Configuração inicial do portal',
    setup_lead: 'Cadastre o primeiro administrador do ambiente de assinaturas.',
    invitation_title: 'Bem-vindo à área de assinaturas',
    invitation_lead: 'Defina sua senha para concluir o convite e entrar no portal.',
    signer_kicker: 'Ambiente seguro de assinatura',
    signer_help: 'Revise o documento com atenção e siga as etapas indicadas na tela.',
    completed_title: 'Documento concluído',
    support: "Suporte: #{SUPPORT_EMAIL}",
    legal_attribution: 'Tecnologia de código aberto DocuSeal'
  }.freeze

  module_function

  def copy(key)
    COPY.fetch(key)
  end
end
