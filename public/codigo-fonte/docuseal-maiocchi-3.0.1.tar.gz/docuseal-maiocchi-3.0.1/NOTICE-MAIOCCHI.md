# Maiocchi Assinaturas — aviso de personalização

Este repositório contém uma distribuição personalizada do DocuSeal 3.0.1 para o portal de assinaturas de **Roger Maiocchi, advogado**.

## Identidade aplicada

- produto visível: **Maiocchi Assinaturas**;
- contato administrativo: **admin@maiocchi.adv.br**;
- paleta institucional: `#0a0a0a`, `#f6f5f1` e `#ffc400`;
- marca visual e ícones próprios do escritório nas interfaces web, PWA e e-mails.

## Software de origem e licença

O motor de documentos e assinaturas permanece DocuSeal. A atribuição discreta “Tecnologia de código aberto DocuSeal” e os links para o código-fonte e a licença são preservados nas interfaces aplicáveis.

- fonte correspondente da versão disponibilizada: <https://assinatura.maiocchi.adv.br/codigo-fonte/>;
- projeto de origem: <https://github.com/docusealco/docuseal/tree/3.0.1>;
- licença do projeto de origem: <https://github.com/docusealco/docuseal/blob/3.0.1/LICENSE>;
- termos adicionais do projeto de origem: <https://github.com/docusealco/docuseal/blob/3.0.1/LICENSE_ADDITIONAL_TERMS>.

A personalização não altera o motor criptográfico, a geração de anexos ou os metadados técnicos de PDF que identificam o software de origem. Os avisos de copyright e licença existentes no código-fonte permanecem vigentes.

## Operação

Solicitações relacionadas ao portal devem ser encaminhadas exclusivamente a **admin@maiocchi.adv.br**. A publicação deve manter acessível a fonte correspondente exata da versão implantada no endereço indicado acima.
